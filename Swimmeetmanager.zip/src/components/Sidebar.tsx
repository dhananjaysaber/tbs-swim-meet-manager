import { Link, useLocation } from 'react-router-dom';

const links = [
  { label: 'Dashboard', path: '/dashboard' },
  { label: 'Meets', path: '/meets' },
  { label: 'Teams', path: '/teams' },
  { label: 'Swimmers', path: '/swimmers' },
  { label: 'Events', path: '/events' },
  { label: 'Entries', path: '/entries' },
  { label: 'Seeding', path: '/seeding' },
  { label: 'Heat Sheets', path: '/heatsheets' },
  { label: 'Run Meet', path: '/runmeet' },
  { label: 'Results', path: '/results' },
  { label: 'Reports', path: '/reports' },
  { label: 'Official Console', path: '/official-console' },
];

export default function Sidebar() {
  const location = useLocation();

  return (
    <aside
      style={{
        borderRight: '1px solid rgba(255,255,255,0.08)',
        padding: 20,
        background: 'rgba(0,0,0,0.14)',
      }}
    >
      <div style={{ marginBottom: 24 }}>
        <h2 style={{ margin: 0, color: '#d4af37' }}>Panthers</h2>
        <p style={{ margin: '6px 0 0', color: '#9fb3c8', fontSize: 14 }}>
          Swim Meet Manager
        </p>
      </div>

      <nav style={{ display: 'grid', gap: 8 }}>
        {links.map((item) => {
          const active = location.pathname === item.path;

          return (
            <Link
              key={item.path}
              to={item.path}
              style={{
                padding: '12px 14px',
                borderRadius: 12,
                background: active ? 'rgba(212,175,55,0.16)' : 'transparent',
                border: active
                  ? '1px solid rgba(212,175,55,0.45)'
                  : '1px solid transparent',
                color: active ? '#f1d67a' : '#f5f7fb',
                textDecoration: 'none',
              }}
            >
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
