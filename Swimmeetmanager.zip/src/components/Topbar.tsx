import { useEffect, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { auth } from '../firebase/auth';

export default function Topbar() {
  const [user, setUser] = useState<User | null>(auth.currentUser);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
    });

    return () => unsub();
  }, []);

  return (
    <header
      style={{
        height: 72,
        borderBottom: '1px solid rgba(255,255,255,0.08)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 24px',
        background: 'rgba(0,0,0,0.12)',
        backdropFilter: 'blur(10px)',
      }}
    >
      <div>
        <div style={{ fontSize: 18, fontWeight: 700 }}>
          Panthers Swim Meet Manager
        </div>
        <div style={{ fontSize: 13, color: '#9fb3c8' }}>Admin Console</div>
      </div>

      <div
        style={{
          padding: '10px 14px',
          borderRadius: 999,
          background: 'rgba(255,255,255,0.06)',
          border: '1px solid rgba(255,255,255,0.08)',
          fontSize: 14,
        }}
      >
        {user?.email || 'Not signed in'}
      </div>
    </header>
  );
}
