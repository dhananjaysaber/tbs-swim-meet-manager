import type { ReactNode } from 'react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';

type AppShellProps = {
  children: ReactNode;
};

const SIDEBAR_WIDTH = 260;
const TOPBAR_HEIGHT = 72;

export default function AppShell({ children }: AppShellProps) {
  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'linear-gradient(180deg, #071426 0%, #0b1f3a 100%)',
        color: '#f5f7fb',
      }}
    >
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: SIDEBAR_WIDTH,
          height: '100vh',
          overflowY: 'auto',
          zIndex: 1000,
          background: 'linear-gradient(180deg, #071426 0%, #0b1f3a 100%)',
          color: '#f5f7fb',
        }}
      >
        <Sidebar />
      </div>

      <div
        style={{
          marginLeft: SIDEBAR_WIDTH,
          minWidth: 0,
          minHeight: '100vh',
          color: '#f5f7fb',
        }}
      >
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: SIDEBAR_WIDTH,
            right: 0,
            height: TOPBAR_HEIGHT,
            zIndex: 1100,
            background: 'linear-gradient(180deg, #071426 0%, #0b1f3a 100%)',
            color: '#f5f7fb',
          }}
        >
          <Topbar />
        </div>

        <main
          style={{
            padding: 24,
            paddingTop: TOPBAR_HEIGHT + 24,
            minHeight: '100vh',
            boxSizing: 'border-box',
            color: '#f5f7fb',
          }}
        >
          {children}
        </main>
      </div>
    </div>
  );
}
