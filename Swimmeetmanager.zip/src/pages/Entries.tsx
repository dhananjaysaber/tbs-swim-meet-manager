import { useEffect, useMemo, useState } from 'react';
import { push, ref, set, onValue, remove, update } from 'firebase/database';
import { auth } from '../firebase/auth.js';
import { db } from '../firebase/db.js';
import AppShell from '../components/AppShell';

type MeetRow = {
  id: string;
  name?: string;
  venue?: string;
  date?: string;
};

type TeamRow = {
  id: string;
  name?: string;
  code?: string;
  seedClub?: string;
  active?: boolean;
  createdAt?: number;
  createdBy?: string;
};

type EventRow = {
  id: string;
  eventNumber?: number;
  distance?: string;
  stroke?: string;
  gender?: string;
  ageGroup?: string;
  eventType?: string;
  relay?: boolean;
  name?: string;
  active?: boolean;
};

type SwimmerRow = {
  id: string;
  firstName?: string;
  lastName?: string;
  fullName?: string;
  gender?: string;
  ageGroup?: string;
  team?: string;
  teamId?: string;
  teamName?: string;
  dob?: string;
  regNo?: string;
  seedClub?: string;
  active?: boolean;
};

type EntryRow = {
  id: string;
  swimmerId?: string;
  swimmerName?: string;
  gender?: string;
  ageGroup?: string;
  teamId?: string;
  teamName?: string;
  eventId?: string;
  eventNumber?: number;
  eventName?: string;
  laneSeedTime?: string;
  status?: string;
  active?: boolean;
  createdAt?: number;
  createdBy?: string;
};

function digitsOnly(value: string) {
  return String(value || '')
    .replace(/\D/g, '')
    .slice(0, 6);
}

function formatSwimTimeFromDigits(value: string) {
  const digits = digitsOnly(value);
  if (!digits) return '';

  const padded = digits.padStart(6, '0');
  const mm = padded.slice(0, 2);
  const ss = padded.slice(2, 4);
  const hh = padded.slice(4, 6);

  return `${mm}:${ss}.${hh}`;
}

function appendDigit(currentDigits: string, digit: string) {
  return digitsOnly(`${currentDigits}${digit}`);
}

function removeLastDigit(currentDigits: string) {
  return digitsOnly(currentDigits).slice(0, -1);
}

function normalizeGender(value?: string) {
  const v = String(value || '')
    .trim()
    .toLowerCase();

  if (['boys', 'boy', 'male', 'm'].includes(v)) return 'boys';
  if (['girls', 'girl', 'female', 'f'].includes(v)) return 'girls';
  if (['mixed', 'mix'].includes(v)) return 'mixed';

  return v;
}

function normalizeAgeGroup(value?: string) {
  return String(value || '')
    .trim()
    .toLowerCase();
}

export default function Entries() {
  const [activeMeetId, setActiveMeetId] = useState('');
  const [activeMeet, setActiveMeet] = useState<MeetRow | null>(null);

  const [teams, setTeams] = useState<TeamRow[]>([]);
  const [events, setEvents] = useState<EventRow[]>([]);
  const [swimmers, setSwimmers] = useState<SwimmerRow[]>([]);
  const [entries, setEntries] = useState<EntryRow[]>([]);

  const [selectedEventId, setSelectedEventId] = useState('');
  const [commonSeedTimeDigits, setCommonSeedTimeDigits] = useState('');
  const [selectedTeamFilter, setSelectedTeamFilter] = useState('');
  const [selectedSwimmerIds, setSelectedSwimmerIds] = useState<string[]>([]);
  const [seedTimeDigitsBySwimmerId, setSeedTimeDigitsBySwimmerId] = useState<
    Record<string, string>
  >({});
  const [selectedEntryIds, setSelectedEntryIds] = useState<string[]>([]);

  const [entriesSearchTerm, setEntriesSearchTerm] = useState('');
  const [entriesTeamFilter, setEntriesTeamFilter] = useState('');
  const [editingEntryId, setEditingEntryId] = useState('');
  const [editEntrySeedDigits, setEditEntrySeedDigits] = useState('');
  const [editEntryStatus, setEditEntryStatus] = useState('Entered');
  const [updatingEntryId, setUpdatingEntryId] = useState('');

  const [msg, setMsg] = useState('');
  const [saving, setSaving] = useState(false);
  const [bulkRemovingEntries, setBulkRemovingEntries] = useState(false);

  const teamsById = useMemo(() => {
    const map: Record<string, TeamRow> = {};
    teams.forEach((team) => {
      map[team.id] = team;
    });
    return map;
  }, [teams]);

  const resolveTeamName = (item: {
    teamId?: string;
    teamName?: string;
    team?: string;
  }) => {
    const currentTeam = item.teamId ? teamsById[item.teamId] : null;
    return currentTeam?.name || item.teamName || item.team || 'No team';
  };

  const activeEvents = useMemo(() => {
    return [...events]
      .filter((event) => event.active !== false)
      .sort((a, b) => Number(a.eventNumber || 0) - Number(b.eventNumber || 0));
  }, [events]);

  const activeSwimmers = useMemo(() => {
    return [...swimmers]
      .filter((swimmer) => swimmer.active !== false)
      .sort((a, b) =>
        String(a.fullName || '').localeCompare(String(b.fullName || ''))
      );
  }, [swimmers]);

  const selectedEvent = useMemo(() => {
    return activeEvents.find((event) => event.id === selectedEventId) || null;
  }, [activeEvents, selectedEventId]);

  const activeMeetLabel = useMemo(() => {
    if (!activeMeet) return 'No active meet selected';
    return `${activeMeet.name || 'Unnamed Meet'} • ${
      activeMeet.venue || 'No venue'
    } • ${activeMeet.date || 'No date'}`;
  }, [activeMeet]);

  const selectedEventEntries = useMemo(() => {
    if (!selectedEventId) return [];

    return entries
      .filter((entry) => entry.eventId === selectedEventId)
      .sort((a, b) =>
        String(a.swimmerName || '').localeCompare(String(b.swimmerName || ''))
      );
  }, [entries, selectedEventId]);

  const entrySwimmerIds = useMemo(() => {
    return new Set(selectedEventEntries.map((entry) => entry.swimmerId || ''));
  }, [selectedEventEntries]);

  const eligibleSwimmers = useMemo(() => {
    if (!selectedEvent) return [];

    const eventGender = normalizeGender(selectedEvent.gender);
    const eventAgeGroup = normalizeAgeGroup(selectedEvent.ageGroup);

    return activeSwimmers.filter((swimmer) => {
      const swimmerGender = normalizeGender(swimmer.gender);
      const swimmerAgeGroup = normalizeAgeGroup(swimmer.ageGroup);

      const genderMatch =
        eventGender === 'mixed' ? true : swimmerGender === eventGender;

      const ageGroupMatch = swimmerAgeGroup === eventAgeGroup;

      return genderMatch && ageGroupMatch;
    });
  }, [activeSwimmers, selectedEvent]);

  const teamOptions = useMemo(() => {
    const map = new Map<string, string>();

    eligibleSwimmers.forEach((swimmer) => {
      const id = String(swimmer.teamId || '').trim();
      const name = resolveTeamName(swimmer).trim();
      if (id && name) map.set(id, name);
    });

    return Array.from(map.entries())
      .map(([id, name]) => ({ id, name }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [eligibleSwimmers, teamsById]);

  const filteredEligibleSwimmers = useMemo(() => {
    let rows = [...eligibleSwimmers];

    if (selectedTeamFilter) {
      rows = rows.filter(
        (swimmer) => String(swimmer.teamId || '') === selectedTeamFilter
      );
    }

    return rows;
  }, [eligibleSwimmers, selectedTeamFilter]);

  const availableEligibleSwimmers = useMemo(() => {
    return filteredEligibleSwimmers.filter(
      (swimmer) => !entrySwimmerIds.has(swimmer.id)
    );
  }, [filteredEligibleSwimmers, entrySwimmerIds]);

  const selectedCount = useMemo(() => {
    return selectedSwimmerIds.length;
  }, [selectedSwimmerIds]);

  const selectedEntryCount = useMemo(() => {
    return selectedEntryIds.length;
  }, [selectedEntryIds]);

  const selectedEventEntryTeamOptions = useMemo(() => {
    const map = new Map<string, string>();

    selectedEventEntries.forEach((entry) => {
      const id = String(entry.teamId || '').trim();
      const name = resolveTeamName({
        teamId: entry.teamId,
        teamName: entry.teamName,
      }).trim();

      if (id && name) map.set(id, name);
    });

    return Array.from(map.entries())
      .map(([id, name]) => ({ id, name }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [selectedEventEntries, teamsById]);

  const filteredSelectedEventEntries = useMemo(() => {
    let rows = [...selectedEventEntries];

    if (entriesTeamFilter) {
      rows = rows.filter(
        (entry) => String(entry.teamId || '') === entriesTeamFilter
      );
    }

    const q = entriesSearchTerm.trim().toLowerCase();

    if (!q) return rows;

    return rows.filter((entry) => {
      const resolvedTeamName = resolveTeamName({
        teamId: entry.teamId,
        teamName: entry.teamName,
      });

      const haystack = [
        entry.swimmerName || '',
        resolvedTeamName || '',
        entry.gender || '',
        entry.ageGroup || '',
        entry.laneSeedTime || '',
        entry.status || '',
      ]
        .join(' ')
        .toLowerCase();

      return haystack.includes(q);
    });
  }, [selectedEventEntries, entriesTeamFilter, entriesSearchTerm, teamsById]);

  useEffect(() => {
    const activeRef = ref(db, 'appState/activeMeetId');

    const unsub = onValue(activeRef, (snap) => {
      const meetId = snap.val() || '';
      setActiveMeetId(meetId);
    });

    return () => unsub();
  }, []);

  useEffect(() => {
    if (!activeMeetId) {
      setActiveMeet(null);
      return;
    }

    const meetRef = ref(db, `meets/${activeMeetId}`);

    const unsub = onValue(meetRef, (snap) => {
      if (!snap.exists()) {
        setActiveMeet(null);
        return;
      }

      const meetData = snap.val();

      setActiveMeet({
        id: activeMeetId,
        ...meetData,
      });
    });

    return () => unsub();
  }, [activeMeetId]);

  useEffect(() => {
    if (!activeMeetId) {
      setTeams([]);
      setEvents([]);
      setSwimmers([]);
      setEntries([]);
      setSelectedEventId('');
      setSelectedSwimmerIds([]);
      setSelectedTeamFilter('');
      setCommonSeedTimeDigits('');
      setSeedTimeDigitsBySwimmerId({});
      setSelectedEntryIds([]);
      setEntriesSearchTerm('');
      setEntriesTeamFilter('');
      setEditingEntryId('');
      setEditEntrySeedDigits('');
      setEditEntryStatus('Entered');
      return;
    }

    const teamsRef = ref(db, `meets/${activeMeetId}/teams`);
    const eventsRef = ref(db, `meets/${activeMeetId}/events`);
    const swimmersRef = ref(db, `meets/${activeMeetId}/swimmers`);
    const entriesRef = ref(db, `meets/${activeMeetId}/entries`);

    const unsubTeams = onValue(teamsRef, (snap) => {
      const val = snap.val();

      if (!val) {
        setTeams([]);
        return;
      }

      const rows: TeamRow[] = Object.entries(val).map(([id, item]: any) => ({
        id,
        ...item,
      }));

      rows.sort((a, b) =>
        String(a.name || '').localeCompare(String(b.name || ''))
      );
      setTeams(rows);
    });

    const unsubEvents = onValue(eventsRef, (snap) => {
      const val = snap.val();

      if (!val) {
        setEvents([]);
        setSelectedEventId('');
        return;
      }

      const rows: EventRow[] = Object.entries(val).map(([id, item]: any) => ({
        id,
        ...item,
      }));

      rows.sort(
        (a, b) => Number(a.eventNumber || 0) - Number(b.eventNumber || 0)
      );
      setEvents(rows);

      setSelectedEventId((prev) => {
        if (
          prev &&
          rows.some((event) => event.id === prev && event.active !== false)
        ) {
          return prev;
        }
        const firstActive = rows.find((event) => event.active !== false);
        return firstActive?.id || '';
      });
    });

    const unsubSwimmers = onValue(swimmersRef, (snap) => {
      const val = snap.val();

      if (!val) {
        setSwimmers([]);
        return;
      }

      const rows: SwimmerRow[] = Object.entries(val).map(([id, item]: any) => ({
        id,
        ...item,
      }));

      rows.sort((a, b) =>
        String(a.fullName || '').localeCompare(String(b.fullName || ''))
      );

      setSwimmers(rows);
    });

    const unsubEntries = onValue(entriesRef, (snap) => {
      const val = snap.val();

      if (!val) {
        setEntries([]);
        return;
      }

      const rows: EntryRow[] = Object.entries(val).map(([id, item]: any) => ({
        id,
        ...item,
      }));

      setEntries(rows);
    });

    return () => {
      unsubTeams();
      unsubEvents();
      unsubSwimmers();
      unsubEntries();
    };
  }, [activeMeetId]);

  useEffect(() => {
    setSelectedSwimmerIds([]);
    setSelectedTeamFilter('');
    setCommonSeedTimeDigits('');
    setSeedTimeDigitsBySwimmerId({});
    setSelectedEntryIds([]);
    setEntriesSearchTerm('');
    setEntriesTeamFilter('');
    setEditingEntryId('');
    setEditEntrySeedDigits('');
    setEditEntryStatus('Entered');
  }, [selectedEventId]);

  useEffect(() => {
    setSelectedSwimmerIds((prev) =>
      prev.filter((id) =>
        availableEligibleSwimmers.some((swimmer) => swimmer.id === id)
      )
    );

    setSeedTimeDigitsBySwimmerId((prev) => {
      const next: Record<string, string> = {};
      availableEligibleSwimmers.forEach((swimmer) => {
        if (prev[swimmer.id] !== undefined) {
          next[swimmer.id] = prev[swimmer.id];
        }
      });
      return next;
    });
  }, [availableEligibleSwimmers]);

  useEffect(() => {
    setSelectedEntryIds((prev) =>
      prev.filter((id) =>
        filteredSelectedEventEntries.some((entry) => entry.id === id)
      )
    );
  }, [filteredSelectedEventEntries]);

  const toggleSwimmerSelection = (swimmerId: string) => {
    setSelectedSwimmerIds((prev) => {
      if (prev.includes(swimmerId)) {
        return prev.filter((id) => id !== swimmerId);
      }
      return [...prev, swimmerId];
    });
  };

  const handleSelectAllEligible = () => {
    setSelectedSwimmerIds(
      availableEligibleSwimmers.map((swimmer) => swimmer.id)
    );
  };

  const handleClearSelection = () => {
    setSelectedSwimmerIds([]);
  };

  const toggleEntrySelection = (entryId: string) => {
    setSelectedEntryIds((prev) => {
      if (prev.includes(entryId)) {
        return prev.filter((id) => id !== entryId);
      }
      return [...prev, entryId];
    });
  };

  const handleSelectAllEntries = () => {
    setSelectedEntryIds(filteredSelectedEventEntries.map((entry) => entry.id));
  };

  const handleClearEntrySelection = () => {
    setSelectedEntryIds([]);
  };

  const handleCommonSeedKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    const key = e.key;

    if (/^\d$/.test(key)) {
      e.preventDefault();
      setCommonSeedTimeDigits((prev) => appendDigit(prev, key));
      return;
    }

    if (key === 'Backspace') {
      e.preventDefault();
      setCommonSeedTimeDigits((prev) => removeLastDigit(prev));
      return;
    }

    if (key === 'Delete') {
      e.preventDefault();
      setCommonSeedTimeDigits('');
      return;
    }

    if (
      key === 'Tab' ||
      key === 'Enter' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      key === 'ArrowUp' ||
      key === 'ArrowDown' ||
      key === 'Home' ||
      key === 'End'
    ) {
      return;
    }

    e.preventDefault();
  };

  const handleRowSeedKeyDown = (
    swimmerId: string,
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    const key = e.key;

    if (/^\d$/.test(key)) {
      e.preventDefault();
      setSeedTimeDigitsBySwimmerId((prev) => ({
        ...prev,
        [swimmerId]: appendDigit(prev[swimmerId] || '', key),
      }));
      return;
    }

    if (key === 'Backspace') {
      e.preventDefault();
      setSeedTimeDigitsBySwimmerId((prev) => ({
        ...prev,
        [swimmerId]: removeLastDigit(prev[swimmerId] || ''),
      }));
      return;
    }

    if (key === 'Delete') {
      e.preventDefault();
      setSeedTimeDigitsBySwimmerId((prev) => ({
        ...prev,
        [swimmerId]: '',
      }));
      return;
    }

    if (
      key === 'Tab' ||
      key === 'Enter' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      key === 'ArrowUp' ||
      key === 'ArrowDown' ||
      key === 'Home' ||
      key === 'End'
    ) {
      return;
    }

    e.preventDefault();
  };

  const handleEditEntrySeedKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    const key = e.key;

    if (/^\d$/.test(key)) {
      e.preventDefault();
      setEditEntrySeedDigits((prev) => appendDigit(prev, key));
      return;
    }

    if (key === 'Backspace') {
      e.preventDefault();
      setEditEntrySeedDigits((prev) => removeLastDigit(prev));
      return;
    }

    if (key === 'Delete') {
      e.preventDefault();
      setEditEntrySeedDigits('');
      return;
    }

    if (
      key === 'Tab' ||
      key === 'Enter' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      key === 'ArrowUp' ||
      key === 'ArrowDown' ||
      key === 'Home' ||
      key === 'End'
    ) {
      return;
    }

    e.preventDefault();
  };

  const handlePasteSeedTime = (
    value: string,
    setDigits: (updater: (prev: string) => string) => void
  ) => {
    const pastedDigits = digitsOnly(value);
    setDigits(() => pastedDigits);
  };

  const resolveSeedTimeForSwimmer = (swimmerId: string) => {
    const rowDigits = digitsOnly(seedTimeDigitsBySwimmerId[swimmerId] || '');
    if (rowDigits) return formatSwimTimeFromDigits(rowDigits);

    const commonDigits = digitsOnly(commonSeedTimeDigits);
    if (commonDigits) return formatSwimTimeFromDigits(commonDigits);

    return '';
  };

  const handleAddEntry = async (swimmer: SwimmerRow) => {
    if (!activeMeetId) {
      setMsg('Please select an active meet first from the Meets page');
      return;
    }

    if (!selectedEvent) {
      setMsg('Please select an event');
      return;
    }

    if (entrySwimmerIds.has(swimmer.id)) {
      setMsg('This swimmer is already entered in the selected event');
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      setMsg('You are not logged in');
      return;
    }

    const resolvedTeamName = resolveTeamName(swimmer);

    setSaving(true);
    setMsg(`Adding ${swimmer.fullName || 'swimmer'} to event...`);

    try {
      const newEntryRef = push(ref(db, `meets/${activeMeetId}/entries`));

      await set(newEntryRef, {
        swimmerId: swimmer.id,
        swimmerName: swimmer.fullName || '',
        gender: swimmer.gender || '',
        ageGroup: swimmer.ageGroup || '',
        teamId: swimmer.teamId || '',
        teamName: resolvedTeamName,
        eventId: selectedEvent.id,
        eventNumber: selectedEvent.eventNumber || 0,
        eventName: selectedEvent.name || '',
        laneSeedTime: resolveSeedTimeForSwimmer(swimmer.id),
        status: 'Entered',
        active: true,
        createdAt: Date.now(),
        createdBy: user.uid,
      });

      setMsg('Entry added successfully');
    } catch (error: any) {
      setMsg(error.message || 'Failed to add entry');
    } finally {
      setSaving(false);
    }
  };

  const handleAddSelectedSwimmers = async () => {
    if (!activeMeetId) {
      setMsg('Please select an active meet first from the Meets page');
      return;
    }

    if (!selectedEvent) {
      setMsg('Please select an event');
      return;
    }

    if (selectedSwimmerIds.length === 0) {
      setMsg('Please select at least one swimmer');
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      setMsg('You are not logged in');
      return;
    }

    const swimmersToAdd = availableEligibleSwimmers.filter((swimmer) =>
      selectedSwimmerIds.includes(swimmer.id)
    );

    if (swimmersToAdd.length === 0) {
      setMsg('No valid swimmers selected to add');
      return;
    }

    setSaving(true);
    setMsg(`Adding ${swimmersToAdd.length} swimmer(s) to event...`);

    try {
      for (const swimmer of swimmersToAdd) {
        const newEntryRef = push(ref(db, `meets/${activeMeetId}/entries`));
        const resolvedTeamName = resolveTeamName(swimmer);

        await set(newEntryRef, {
          swimmerId: swimmer.id,
          swimmerName: swimmer.fullName || '',
          gender: swimmer.gender || '',
          ageGroup: swimmer.ageGroup || '',
          teamId: swimmer.teamId || '',
          teamName: resolvedTeamName,
          eventId: selectedEvent.id,
          eventNumber: selectedEvent.eventNumber || 0,
          eventName: selectedEvent.name || '',
          laneSeedTime: resolveSeedTimeForSwimmer(swimmer.id),
          status: 'Entered',
          active: true,
          createdAt: Date.now(),
          createdBy: user.uid,
        });
      }

      setMsg(`${swimmersToAdd.length} swimmer(s) added successfully`);
      setSelectedSwimmerIds([]);
    } catch (error: any) {
      setMsg(error.message || 'Failed to add selected swimmers');
    } finally {
      setSaving(false);
    }
  };

  const handleStartEditEntry = (entry: EntryRow) => {
    setEditingEntryId(entry.id);
    setEditEntrySeedDigits(digitsOnly(entry.laneSeedTime || ''));
    setEditEntryStatus(entry.status || 'Entered');
    setMsg('');
  };

  const handleCancelEditEntry = () => {
    setEditingEntryId('');
    setEditEntrySeedDigits('');
    setEditEntryStatus('Entered');
  };

  const handleSaveEntryUpdate = async (entry: EntryRow) => {
    if (!activeMeetId) {
      setMsg('Please select an active meet first from the Meets page');
      return;
    }

    setUpdatingEntryId(entry.id);
    setMsg(`Updating ${entry.swimmerName || 'entry'}...`);

    try {
      await update(ref(db, `meets/${activeMeetId}/entries/${entry.id}`), {
        laneSeedTime: formatSwimTimeFromDigits(editEntrySeedDigits),
        status: editEntryStatus || 'Entered',
        teamName: resolveTeamName({
          teamId: entry.teamId,
          teamName: entry.teamName,
        }),
      });

      setMsg('Entry updated successfully');
      handleCancelEditEntry();
    } catch (error: any) {
      setMsg(error.message || 'Failed to update entry');
    } finally {
      setUpdatingEntryId('');
    }
  };

  const handleRemoveEntry = async (entry: EntryRow) => {
    const ok = window.confirm(
      `Remove "${entry.swimmerName || 'swimmer'}" from "${
        entry.eventName || 'event'
      }"?`
    );
    if (!ok) return;

    try {
      await remove(ref(db, `meets/${activeMeetId}/entries/${entry.id}`));
      setMsg('Entry removed successfully');
      setSelectedEntryIds((prev) => prev.filter((id) => id !== entry.id));
    } catch (error: any) {
      setMsg(error.message || 'Failed to remove entry');
    }
  };

  const handleBulkRemoveEntries = async () => {
    if (selectedEntryIds.length === 0) {
      setMsg('Please select at least one entry');
      return;
    }

    const ok = window.confirm(
      `Remove ${selectedEntryIds.length} selected entr${
        selectedEntryIds.length === 1 ? 'y' : 'ies'
      } from this event?`
    );
    if (!ok) return;

    setBulkRemovingEntries(true);
    setMsg(
      `Removing ${selectedEntryIds.length} selected entr${
        selectedEntryIds.length === 1 ? 'y' : 'ies'
      }...`
    );

    try {
      for (const entryId of selectedEntryIds) {
        await remove(ref(db, `meets/${activeMeetId}/entries/${entryId}`));
      }

      setMsg(
        `${selectedEntryIds.length} entr${
          selectedEntryIds.length === 1 ? 'y' : 'ies'
        } removed successfully`
      );
      setSelectedEntryIds([]);
    } catch (error: any) {
      setMsg(error.message || 'Failed to remove selected entries');
    } finally {
      setBulkRemovingEntries(false);
    }
  };

  return (
    <AppShell>
      <div style={{ display: 'grid', gap: 20 }}>
        <div
          style={{
            background: activeMeetId
              ? 'rgba(46,175,109,0.10)'
              : 'rgba(217,83,79,0.10)',
            border: activeMeetId
              ? '1px solid rgba(46,175,109,0.28)'
              : '1px solid rgba(217,83,79,0.28)',
            borderRadius: 18,
            padding: 18,
          }}
        >
          <h2 style={{ marginTop: 0, marginBottom: 8 }}>Active Meet</h2>
          <div style={{ color: activeMeetId ? '#d7ffe8' : '#ffd6d3' }}>
            {activeMeetLabel}
          </div>
        </div>

        <div style={panelStyle}>
          <h1 style={{ marginTop: 0 }}>Entries</h1>
          <p style={{ color: '#9fb3c8', marginTop: 0 }}>
            Link swimmers into events for the currently active meet.
          </p>

          <div style={gridStyle}>
            <div>
              <label style={labelStyle}>Select Event</label>
              <select
                value={selectedEventId}
                onChange={(e) => setSelectedEventId(e.target.value)}
                style={inputStyle}
              >
                {activeEvents.length === 0 ? (
                  <option value="">No active events found</option>
                ) : (
                  <>
                    <option value="">Select Event</option>
                    {activeEvents.map((event) => (
                      <option key={event.id} value={event.id}>
                        Event {event.eventNumber || '—'} • {event.name}
                      </option>
                    ))}
                  </>
                )}
              </select>
            </div>

            <div>
              <label style={labelStyle}>Common Optional Seed Time</label>
              <input
                type="text"
                value={formatSwimTimeFromDigits(commonSeedTimeDigits)}
                onKeyDown={handleCommonSeedKeyDown}
                onPaste={(e) => {
                  e.preventDefault();
                  handlePasteSeedTime(
                    e.clipboardData.getData('text'),
                    (updater) => setCommonSeedTimeDigits(updater)
                  );
                }}
                inputMode="numeric"
                placeholder="Enter digits only"
                style={inputStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>Filter by Team</label>
              <select
                value={selectedTeamFilter}
                onChange={(e) => setSelectedTeamFilter(e.target.value)}
                style={inputStyle}
              >
                <option value="">All Teams</option>
                {teamOptions.map((team) => (
                  <option key={team.id} value={team.id}>
                    {team.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {selectedEvent ? (
            <div
              style={{
                marginTop: 16,
                padding: 14,
                borderRadius: 14,
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)',
              }}
            >
              <div style={{ fontWeight: 700, color: '#fff' }}>
                Event {selectedEvent.eventNumber || '—'} •{' '}
                {selectedEvent.name || '—'}
              </div>

              <div
                style={{
                  display: 'flex',
                  gap: 10,
                  flexWrap: 'wrap',
                  marginTop: 10,
                }}
              >
                <span style={pillStyle}>
                  Gender: {selectedEvent.gender || '—'}
                </span>
                <span style={pillStyle}>
                  Category: {selectedEvent.ageGroup || '—'}
                </span>
                <span style={pillStyle}>
                  Type: {selectedEvent.eventType || '—'}
                </span>
                <span style={pillStyle}>
                  Stroke: {selectedEvent.stroke || '—'}
                </span>
              </div>
            </div>
          ) : null}

          <p style={{ marginTop: 16, color: '#f1d67a' }}>{msg}</p>
        </div>

        <div style={panelStyle}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              gap: 12,
              flexWrap: 'wrap',
              alignItems: 'center',
            }}
          >
            <div>
              <h2 style={{ marginTop: 0, marginBottom: 6 }}>
                Eligible Swimmers
              </h2>
              <div style={{ color: '#9fb3c8' }}>
                Select swimmers, optionally set seed time, then add selected
                swimmers.
              </div>
            </div>

            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <button
                onClick={handleSelectAllEligible}
                disabled={availableEligibleSwimmers.length === 0}
                style={
                  availableEligibleSwimmers.length === 0
                    ? disabledBtnStyle
                    : secondaryBtnStyle
                }
              >
                Select All Eligible
              </button>

              <button
                onClick={handleClearSelection}
                disabled={selectedCount === 0}
                style={
                  selectedCount === 0 ? disabledBtnStyle : secondaryBtnStyle
                }
              >
                Clear Selection
              </button>

              <button
                onClick={handleAddSelectedSwimmers}
                disabled={selectedCount === 0 || saving}
                style={
                  selectedCount === 0 || saving
                    ? disabledBtnStyle
                    : primaryBtnStyle
                }
              >
                {saving
                  ? 'Adding...'
                  : `Add Selected Swimmers (${selectedCount})`}
              </button>
            </div>
          </div>

          {!activeMeetId ? (
            <p style={{ color: '#ffd6d3', marginTop: 16 }}>
              Please select an active meet first from the Meets page.
            </p>
          ) : !selectedEvent ? (
            <p style={{ color: '#9fb3c8', marginTop: 16 }}>
              Please select an event first.
            </p>
          ) : filteredEligibleSwimmers.length === 0 ? (
            <p style={{ color: '#9fb3c8', marginTop: 16 }}>
              No eligible swimmers found for this event. Check that swimmer
              gender and category match the selected event.
            </p>
          ) : (
            <div
              style={{
                marginTop: 16,
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: 16,
                overflow: 'hidden',
                background: 'rgba(255,255,255,0.03)',
              }}
            >
              <div
                style={{
                  maxHeight: 440,
                  overflow: 'auto',
                }}
              >
                <table
                  style={{
                    width: '100%',
                    borderCollapse: 'collapse',
                    minWidth: 980,
                  }}
                >
                  <thead
                    style={{
                      position: 'sticky',
                      top: 0,
                      zIndex: 2,
                      background: '#132238',
                    }}
                  >
                    <tr>
                      {[
                        'Select',
                        'Reg No',
                        'Name',
                        'Team',
                        'Gender',
                        'Category',
                        'Seed Club',
                        'Optional Seed Time',
                        'Status',
                        'Action',
                      ].map((head) => (
                        <th
                          key={head}
                          style={{
                            textAlign: 'left',
                            padding: '12px 14px',
                            fontSize: 13,
                            color: '#f1d67a',
                            borderBottom: '1px solid rgba(255,255,255,0.08)',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {head}
                        </th>
                      ))}
                    </tr>
                  </thead>

                  <tbody>
                    {filteredEligibleSwimmers.map((swimmer) => {
                      const alreadyEntered = entrySwimmerIds.has(swimmer.id);
                      const isChecked = selectedSwimmerIds.includes(swimmer.id);
                      const resolvedTeamName = resolveTeamName(swimmer);

                      return (
                        <tr
                          key={swimmer.id}
                          style={{
                            opacity: alreadyEntered ? 0.65 : 1,
                            background: alreadyEntered
                              ? 'rgba(46,175,109,0.05)'
                              : 'transparent',
                          }}
                        >
                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              disabled={alreadyEntered}
                              onChange={() =>
                                toggleSwimmerSelection(swimmer.id)
                              }
                              style={{ transform: 'scale(1.1)' }}
                            />
                          </td>

                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {swimmer.regNo || '—'}
                          </td>

                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                              fontWeight: 700,
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {swimmer.fullName || 'Unnamed Swimmer'}
                          </td>

                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {resolvedTeamName}
                          </td>

                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {swimmer.gender || '—'}
                          </td>

                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {swimmer.ageGroup || '—'}
                          </td>

                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {swimmer.seedClub || '—'}
                          </td>

                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                              minWidth: 180,
                            }}
                          >
                            <input
                              type="text"
                              value={formatSwimTimeFromDigits(
                                seedTimeDigitsBySwimmerId[swimmer.id] || ''
                              )}
                              onKeyDown={(e) =>
                                handleRowSeedKeyDown(swimmer.id, e)
                              }
                              onPaste={(e) => {
                                e.preventDefault();
                                const pastedText =
                                  e.clipboardData.getData('text');
                                setSeedTimeDigitsBySwimmerId((prev) => ({
                                  ...prev,
                                  [swimmer.id]: digitsOnly(pastedText),
                                }));
                              }}
                              inputMode="numeric"
                              placeholder="Enter digits"
                              disabled={alreadyEntered}
                              style={inputStyle}
                            />
                          </td>

                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            <span
                              style={{
                                display: 'inline-block',
                                padding: '6px 10px',
                                borderRadius: 999,
                                background: alreadyEntered
                                  ? 'rgba(46,175,109,0.16)'
                                  : isChecked
                                  ? 'rgba(212,175,55,0.18)'
                                  : 'rgba(255,255,255,0.06)',
                                border: alreadyEntered
                                  ? '1px solid rgba(46,175,109,0.35)'
                                  : isChecked
                                  ? '1px solid rgba(212,175,55,0.35)'
                                  : '1px solid rgba(255,255,255,0.12)',
                                color: alreadyEntered
                                  ? '#d7ffe8'
                                  : isChecked
                                  ? '#f3d97b'
                                  : '#fff',
                                fontSize: 12,
                              }}
                            >
                              {alreadyEntered
                                ? 'Already Entered'
                                : isChecked
                                ? 'Selected'
                                : 'Eligible'}
                            </span>
                          </td>

                          <td
                            style={{
                              padding: '12px 14px',
                              borderBottom: '1px solid rgba(255,255,255,0.06)',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            <button
                              onClick={() => handleAddEntry(swimmer)}
                              disabled={alreadyEntered || saving}
                              style={
                                alreadyEntered
                                  ? disabledBtnStyle
                                  : secondaryBtnStyle
                              }
                            >
                              {alreadyEntered ? 'Already Added' : 'Add'}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        <div style={panelStyle}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              gap: 12,
              flexWrap: 'wrap',
              alignItems: 'center',
            }}
          >
            <div>
              <h2 style={{ marginTop: 0, marginBottom: 6 }}>
                Entries for Selected Event
              </h2>
              <div style={{ color: '#9fb3c8' }}>
                Quick search, filter, edit and remove entries in compact table
                view.
              </div>
            </div>

            {filteredSelectedEventEntries.length > 0 ? (
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                <button
                  onClick={handleSelectAllEntries}
                  disabled={filteredSelectedEventEntries.length === 0}
                  style={
                    filteredSelectedEventEntries.length === 0
                      ? disabledBtnStyle
                      : secondaryBtnStyle
                  }
                >
                  Select All Entries
                </button>

                <button
                  onClick={handleClearEntrySelection}
                  disabled={selectedEntryCount === 0}
                  style={
                    selectedEntryCount === 0
                      ? disabledBtnStyle
                      : secondaryBtnStyle
                  }
                >
                  Clear Selection
                </button>

                <button
                  onClick={handleBulkRemoveEntries}
                  disabled={selectedEntryCount === 0 || bulkRemovingEntries}
                  style={
                    selectedEntryCount === 0 || bulkRemovingEntries
                      ? disabledBtnStyle
                      : dangerBtnStyle
                  }
                >
                  {bulkRemovingEntries
                    ? 'Removing...'
                    : `Remove Selected (${selectedEntryCount})`}
                </button>
              </div>
            ) : null}
          </div>

          {!activeMeetId ? (
            <p style={{ color: '#ffd6d3', marginTop: 16 }}>
              Please select an active meet first from the Meets page.
            </p>
          ) : !selectedEvent ? (
            <p style={{ color: '#9fb3c8', marginTop: 16 }}>
              Please select an event first.
            </p>
          ) : selectedEventEntries.length === 0 ? (
            <p style={{ color: '#9fb3c8', marginTop: 16 }}>
              No swimmers entered in this event yet.
            </p>
          ) : (
            <>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns:
                    'minmax(260px, 1fr) minmax(220px, 280px)',
                  gap: 14,
                  marginTop: 16,
                }}
              >
                <div>
                  <label style={labelStyle}>Search Swimmer</label>
                  <input
                    value={entriesSearchTerm}
                    onChange={(e) => setEntriesSearchTerm(e.target.value)}
                    placeholder="Search by swimmer, team, category, status..."
                    style={inputStyle}
                  />
                </div>

                <div>
                  <label style={labelStyle}>Filter by Team</label>
                  <select
                    value={entriesTeamFilter}
                    onChange={(e) => setEntriesTeamFilter(e.target.value)}
                    style={inputStyle}
                  >
                    <option value="">All Teams</option>
                    {selectedEventEntryTeamOptions.map((team) => (
                      <option key={team.id} value={team.id}>
                        {team.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {filteredSelectedEventEntries.length === 0 ? (
                <p style={{ color: '#9fb3c8', marginTop: 16 }}>
                  No entries found for your filter/search.
                </p>
              ) : (
                <div
                  style={{
                    marginTop: 16,
                    border: '1px solid rgba(255,255,255,0.08)',
                    borderRadius: 16,
                    overflow: 'hidden',
                    background: 'rgba(255,255,255,0.03)',
                  }}
                >
                  <div
                    style={{
                      maxHeight: 440,
                      overflow: 'auto',
                    }}
                  >
                    <table
                      style={{
                        width: '100%',
                        borderCollapse: 'collapse',
                        minWidth: 1080,
                      }}
                    >
                      <thead
                        style={{
                          position: 'sticky',
                          top: 0,
                          zIndex: 2,
                          background: '#132238',
                        }}
                      >
                        <tr>
                          {[
                            'Select',
                            'Swimmer',
                            'Team',
                            'Gender',
                            'Category',
                            'Seed Time',
                            'Status',
                            'Action',
                          ].map((head) => (
                            <th
                              key={head}
                              style={{
                                textAlign: 'left',
                                padding: '12px 14px',
                                fontSize: 13,
                                color: '#f1d67a',
                                borderBottom:
                                  '1px solid rgba(255,255,255,0.08)',
                                whiteSpace: 'nowrap',
                              }}
                            >
                              {head}
                            </th>
                          ))}
                        </tr>
                      </thead>

                      <tbody>
                        {filteredSelectedEventEntries.map((entry, index) => {
                          const isSelected = selectedEntryIds.includes(
                            entry.id
                          );
                          const isEditing = editingEntryId === entry.id;
                          const resolvedEntryTeamName = resolveTeamName({
                            teamId: entry.teamId,
                            teamName: entry.teamName,
                          });

                          return (
                            <tr
                              key={entry.id}
                              style={{
                                background:
                                  index % 2 === 0
                                    ? 'rgba(255,255,255,0.02)'
                                    : 'rgba(255,255,255,0.05)',
                              }}
                            >
                              <td
                                style={{
                                  padding: '12px 14px',
                                  borderBottom:
                                    '1px solid rgba(255,255,255,0.06)',
                                }}
                              >
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={() =>
                                    toggleEntrySelection(entry.id)
                                  }
                                  style={{ transform: 'scale(1.1)' }}
                                />
                              </td>

                              <td
                                style={{
                                  padding: '12px 14px',
                                  borderBottom:
                                    '1px solid rgba(255,255,255,0.06)',
                                  fontWeight: 700,
                                  whiteSpace: 'nowrap',
                                }}
                              >
                                {entry.swimmerName || 'Unnamed Swimmer'}
                              </td>

                              <td
                                style={{
                                  padding: '12px 14px',
                                  borderBottom:
                                    '1px solid rgba(255,255,255,0.06)',
                                  whiteSpace: 'nowrap',
                                }}
                              >
                                {resolvedEntryTeamName}
                              </td>

                              <td
                                style={{
                                  padding: '12px 14px',
                                  borderBottom:
                                    '1px solid rgba(255,255,255,0.06)',
                                  whiteSpace: 'nowrap',
                                }}
                              >
                                {entry.gender || '—'}
                              </td>

                              <td
                                style={{
                                  padding: '12px 14px',
                                  borderBottom:
                                    '1px solid rgba(255,255,255,0.06)',
                                  whiteSpace: 'nowrap',
                                }}
                              >
                                {entry.ageGroup || '—'}
                              </td>

                              <td
                                style={{
                                  padding: '12px 14px',
                                  borderBottom:
                                    '1px solid rgba(255,255,255,0.06)',
                                  minWidth: 170,
                                }}
                              >
                                {isEditing ? (
                                  <input
                                    type="text"
                                    value={formatSwimTimeFromDigits(
                                      editEntrySeedDigits
                                    )}
                                    onKeyDown={handleEditEntrySeedKeyDown}
                                    onPaste={(e) => {
                                      e.preventDefault();
                                      const pastedText =
                                        e.clipboardData.getData('text');
                                      setEditEntrySeedDigits(
                                        digitsOnly(pastedText)
                                      );
                                    }}
                                    inputMode="numeric"
                                    placeholder="Enter digits"
                                    style={inputStyle}
                                  />
                                ) : (
                                  entry.laneSeedTime || '—'
                                )}
                              </td>

                              <td
                                style={{
                                  padding: '12px 14px',
                                  borderBottom:
                                    '1px solid rgba(255,255,255,0.06)',
                                  minWidth: 150,
                                  whiteSpace: 'nowrap',
                                }}
                              >
                                {isEditing ? (
                                  <select
                                    value={editEntryStatus}
                                    onChange={(e) =>
                                      setEditEntryStatus(e.target.value)
                                    }
                                    style={inputStyle}
                                  >
                                    <option value="Entered">Entered</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Confirmed">Confirmed</option>
                                    <option value="Scratch">Scratch</option>
                                  </select>
                                ) : (
                                  <span
                                    style={{
                                      display: 'inline-block',
                                      padding: '6px 10px',
                                      borderRadius: 999,
                                      background:
                                        String(
                                          entry.status || 'Entered'
                                        ).toLowerCase() === 'scratch'
                                          ? 'rgba(217,83,79,0.16)'
                                          : 'rgba(46,175,109,0.16)',
                                      border:
                                        String(
                                          entry.status || 'Entered'
                                        ).toLowerCase() === 'scratch'
                                          ? '1px solid rgba(217,83,79,0.35)'
                                          : '1px solid rgba(46,175,109,0.35)',
                                      color:
                                        String(
                                          entry.status || 'Entered'
                                        ).toLowerCase() === 'scratch'
                                          ? '#ffd6d3'
                                          : '#d7ffe8',
                                      fontSize: 12,
                                    }}
                                  >
                                    {entry.status || 'Entered'}
                                  </span>
                                )}
                              </td>

                              <td
                                style={{
                                  padding: '12px 14px',
                                  borderBottom:
                                    '1px solid rgba(255,255,255,0.06)',
                                  whiteSpace: 'nowrap',
                                }}
                              >
                                {isEditing ? (
                                  <div
                                    style={{
                                      display: 'flex',
                                      gap: 8,
                                      flexWrap: 'wrap',
                                    }}
                                  >
                                    <button
                                      onClick={() =>
                                        handleSaveEntryUpdate(entry)
                                      }
                                      disabled={updatingEntryId === entry.id}
                                      style={primaryBtnStyle}
                                    >
                                      {updatingEntryId === entry.id
                                        ? 'Saving...'
                                        : 'Save'}
                                    </button>

                                    <button
                                      onClick={handleCancelEditEntry}
                                      style={secondaryBtnStyle}
                                    >
                                      Cancel
                                    </button>
                                  </div>
                                ) : (
                                  <div
                                    style={{
                                      display: 'flex',
                                      gap: 8,
                                      flexWrap: 'wrap',
                                    }}
                                  >
                                    <button
                                      onClick={() =>
                                        handleStartEditEntry(entry)
                                      }
                                      style={secondaryBtnStyle}
                                    >
                                      Edit
                                    </button>

                                    <button
                                      onClick={() => handleRemoveEntry(entry)}
                                      style={dangerBtnStyle}
                                    >
                                      Remove
                                    </button>
                                  </div>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </AppShell>
  );
}

const panelStyle: React.CSSProperties = {
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 18,
  padding: 20,
};

const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
  gap: 14,
  marginTop: 18,
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  marginBottom: 8,
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '12px 14px',
  borderRadius: 12,
  border: '1px solid rgba(255,255,255,0.12)',
  background: 'rgba(255,255,255,0.06)',
  color: 'white',
  outline: 'none',
};

const primaryBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: 'none',
  background: '#d4af37',
  color: '#071426',
  fontWeight: 700,
  cursor: 'pointer',
};

const secondaryBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: '1px solid rgba(255,255,255,0.12)',
  background: 'rgba(255,255,255,0.04)',
  color: 'white',
  fontWeight: 700,
  cursor: 'pointer',
};

const disabledBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: 'none',
  background: 'rgba(255,255,255,0.10)',
  color: 'rgba(255,255,255,0.55)',
  fontWeight: 700,
  cursor: 'not-allowed',
};

const dangerBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: '1px solid rgba(217,83,79,0.35)',
  background: 'rgba(217,83,79,0.16)',
  color: '#ffd6d3',
  fontWeight: 700,
  cursor: 'pointer',
};

const pillStyle: React.CSSProperties = {
  padding: '8px 12px',
  borderRadius: 999,
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.08)',
  fontSize: 13,
};
