import { useEffect, useMemo, useState, type CSSProperties } from 'react';
import { onValue, push, ref, remove, set, update } from 'firebase/database';
import { db } from '../firebase/db';

type MeetRow = {
  id: string;
  name?: string;
  venue?: string;
  date?: string;
};

type TeamRow = {
  id: string;
  name?: string;
  code?: string;
  seedClub?: string;
  active?: boolean;
};

type TeamPinRow = {
  pin?: string;
  active?: boolean;
  submitted?: boolean;
  createdAt?: number;
  updatedAt?: number;
  createdBy?: string;
  updatedBy?: string;
  lastSubmittedAt?: number;
};

type SwimmerRow = {
  id: string;
  firstName?: string;
  lastName?: string;
  fullName?: string;
  gender?: string;
  ageGroup?: string;
  team?: string;
  teamId?: string;
  teamName?: string;
  dob?: string;
  regNo?: string;
  seedClub?: string;
  active?: boolean;
};

type EventRow = {
  id: string;
  eventNumber?: number;
  distance?: string;
  stroke?: string;
  gender?: string;
  ageGroup?: string;
  eventType?: string;
  relay?: boolean;
  name?: string;
  active?: boolean;
};

type EntryRow = {
  id: string;
  swimmerId?: string;
  swimmerName?: string;
  gender?: string;
  ageGroup?: string;
  teamId?: string;
  teamName?: string;
  eventId?: string;
  eventNumber?: number;
  eventName?: string;
  laneSeedTime?: string;
  status?: string;
  active?: boolean;
  createdAt?: number;
  createdBy?: string;
};

type TeamReviewRow = {
  submitted?: boolean;
  submittedAt?: number;
  submittedByTeamId?: string;
  teamName?: string;
  totalSwimmers?: number;
  totalEntries?: number;
  eventSummary?: Record<
    string,
    {
      eventId?: string;
      eventName?: string;
      eventNumber?: number;
      swimmerCount?: number;
    }
  >;
};

type ManageMode = 'BY_NAME' | 'BY_EVENT';

type SummaryDetailRow = {
  entryId: string;
  category: string;
  gender: string;
  eventId: string;
  eventNumber: number;
  eventName: string;
  swimmerId: string;
  swimmerName: string;
};

const PANTHERS_LOGO =
  'https://tbspanthers.british-school.org/wp-content/uploads/2025/10/TBSPanthers-Logo-512px.png';

function normalizeGender(value?: string) {
  const v = String(value || '')
    .trim()
    .toLowerCase();

  if (['boys', 'boy', 'male', 'm'].includes(v)) return 'boys';
  if (['girls', 'girl', 'female', 'f'].includes(v)) return 'girls';
  if (['mixed', 'mix'].includes(v)) return 'mixed';

  return v;
}

function normalizeAgeGroup(value?: string) {
  return String(value || '')
    .trim()
    .toLowerCase();
}

function displayGenderLabel(value?: string) {
  const v = normalizeGender(value);
  if (v === 'boys') return 'Boys';
  if (v === 'girls') return 'Girls';
  if (v === 'mixed') return 'Mixed';
  return value || '—';
}

function formatDateTime(value?: number) {
  if (!value) return '—';

  try {
    return new Date(value).toLocaleString();
  } catch {
    return '—';
  }
}

function getQueryParams() {
  const params = new URLSearchParams(window.location.search);
  return {
    meetId: params.get('meetId') || '',
    teamId: params.get('teamId') || '',
  };
}

function isFinalEvent(event: EventRow) {
  const text = `${event.name || ''} ${event.eventType || ''}`.toLowerCase();
  return text.includes('final');
}

function cleanEventName(name?: string) {
  let text = String(name || '').trim();
  if (!text) return 'Unnamed Event';

  text = text.replace(/\s*-\s*final\b.*$/i, '');
  text = text.replace(/\s*-\s*heat\b.*$/i, '');
  text = text.replace(/\bfinal\b/gi, '').trim();
  text = text.replace(/\bheat\b/gi, '').trim();
  text = text.replace(/\s{2,}/g, ' ');
  text = text.replace(/\s*-\s*$/g, '').trim();

  return text || 'Unnamed Event';
}

function eventDisplayLabel(event: EventRow) {
  const base =
    event.distance && event.stroke
      ? `${String(event.distance).trim()} ${String(event.stroke).trim()}`
      : cleanEventName(event.name);

  return `${base} - ${displayGenderLabel(event.gender)} - ${
    event.ageGroup || '—'
  }`;
}

function swimmerDisplayLabel(swimmer: SwimmerRow) {
  const name =
    swimmer.fullName ||
    `${swimmer.firstName || ''} ${swimmer.lastName || ''}`.trim() ||
    'Unnamed Swimmer';

  return `${name} - ${swimmer.ageGroup || '—'} - ${displayGenderLabel(
    swimmer.gender
  )}`;
}

export default function TeamEntries() {
  const [{ meetId, teamId }, setQueryState] = useState(() => getQueryParams());

  const [meet, setMeet] = useState<MeetRow | null>(null);
  const [team, setTeam] = useState<TeamRow | null>(null);
  const [teamPin, setTeamPin] = useState<TeamPinRow | null>(null);
  const [teamReview, setTeamReview] = useState<TeamReviewRow | null>(null);

  const [events, setEvents] = useState<EventRow[]>([]);
  const [swimmers, setSwimmers] = useState<SwimmerRow[]>([]);
  const [entries, setEntries] = useState<EntryRow[]>([]);

  const [enteredPin, setEnteredPin] = useState('');
  const [pinVerified, setPinVerified] = useState(false);
  const [step, setStep] = useState<'pin' | 'manage' | 'summary'>('pin');

  const [saving, setSaving] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [pageLoading, setPageLoading] = useState(true);
  const [loadingMessage, setLoadingMessage] = useState(
    'Loading team manager...'
  );
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState('Team Manager');
  const [modalMessage, setModalMessage] = useState('');

  const [manageMode, setManageMode] = useState<ManageMode>('BY_NAME');

  const [swimmerSearch, setSwimmerSearch] = useState('');
  const [selectedSwimmerId, setSelectedSwimmerId] = useState('');

  const [eventSearch, setEventSearch] = useState('');
  const [selectedEventId, setSelectedEventId] = useState('');

  const [selectedSummaryCategory, setSelectedSummaryCategory] = useState('');

  const openModal = (title: string, message: string) => {
    setModalTitle(title);
    setModalMessage(message);
    setModalOpen(true);
  };

  const closeModal = () => setModalOpen(false);

  useEffect(() => {
    const syncQuery = () => setQueryState(getQueryParams());

    window.addEventListener('popstate', syncQuery);
    syncQuery();

    return () => {
      window.removeEventListener('popstate', syncQuery);
    };
  }, []);

  useEffect(() => {
    if (!meetId) {
      setMeet(null);
      return;
    }

    const meetRef = ref(db, `meets/${meetId}`);

    const unsub = onValue(meetRef, (snap) => {
      if (!snap.exists()) {
        setMeet(null);
        return;
      }

      setMeet({
        id: meetId,
        ...snap.val(),
      });
    });

    return () => unsub();
  }, [meetId]);

  useEffect(() => {
    if (!meetId || !teamId) {
      setTeam(null);
      setTeamPin(null);
      setTeamReview(null);
      setSwimmers([]);
      setEvents([]);
      setEntries([]);
      setPageLoading(false);
      return;
    }

    setPageLoading(true);
    setLoadingMessage('Loading team manager...');

    const teamRef = ref(db, `meets/${meetId}/teams/${teamId}`);
    const pinRef = ref(db, `meets/${meetId}/teamPins/${teamId}`);
    const reviewRef = ref(db, `meets/${meetId}/teamEntryReviews/${teamId}`);
    const swimmersRef = ref(db, `meets/${meetId}/swimmers`);
    const eventsRef = ref(db, `meets/${meetId}/events`);
    const entriesRef = ref(db, `meets/${meetId}/entries`);

    let gotTeam = false;
    let gotPin = false;
    let gotReview = false;
    let gotSwimmers = false;
    let gotEvents = false;
    let gotEntries = false;

    const maybeFinishLoading = () => {
      if (
        gotTeam &&
        gotPin &&
        gotReview &&
        gotSwimmers &&
        gotEvents &&
        gotEntries
      ) {
        setPageLoading(false);
      }
    };

    const unsubTeam = onValue(teamRef, (snap) => {
      if (!snap.exists()) {
        setTeam(null);
      } else {
        setTeam({
          id: teamId,
          ...snap.val(),
        });
      }
      gotTeam = true;
      maybeFinishLoading();
    });

    const unsubPin = onValue(pinRef, (snap) => {
      setTeamPin((snap.val() as TeamPinRow) || null);
      gotPin = true;
      maybeFinishLoading();
    });

    const unsubReview = onValue(reviewRef, (snap) => {
      setTeamReview((snap.val() as TeamReviewRow) || null);
      gotReview = true;
      maybeFinishLoading();
    });

    const unsubSwimmers = onValue(swimmersRef, (snap) => {
      const val = snap.val();

      if (!val) {
        setSwimmers([]);
      } else {
        const rows: SwimmerRow[] = Object.entries(val).map(
          ([id, item]: any) => ({
            id,
            ...item,
          })
        );
        setSwimmers(rows);
      }

      gotSwimmers = true;
      maybeFinishLoading();
    });

    const unsubEvents = onValue(eventsRef, (snap) => {
      const val = snap.val();

      if (!val) {
        setEvents([]);
      } else {
        const rows: EventRow[] = Object.entries(val).map(([id, item]: any) => ({
          id,
          ...item,
        }));

        rows.sort(
          (a, b) => Number(a.eventNumber || 0) - Number(b.eventNumber || 0)
        );

        setEvents(rows);
      }

      gotEvents = true;
      maybeFinishLoading();
    });

    const unsubEntries = onValue(entriesRef, (snap) => {
      const val = snap.val();

      if (!val) {
        setEntries([]);
      } else {
        const rows: EntryRow[] = Object.entries(val).map(([id, item]: any) => ({
          id,
          ...item,
        }));
        setEntries(rows);
      }

      gotEntries = true;
      maybeFinishLoading();
    });

    return () => {
      unsubTeam();
      unsubPin();
      unsubReview();
      unsubSwimmers();
      unsubEvents();
      unsubEntries();
    };
  }, [meetId, teamId]);

  const isPinActive = !!teamPin?.pin && teamPin?.active !== false;
  const isEditable = pinVerified && isPinActive;

  const teamSwimmers = useMemo(() => {
    return swimmers
      .filter(
        (swimmer) =>
          swimmer.active !== false && String(swimmer.teamId || '') === teamId
      )
      .sort((a, b) =>
        String(
          a.fullName || `${a.firstName || ''} ${a.lastName || ''}`.trim()
        ).localeCompare(
          String(
            b.fullName || `${b.firstName || ''} ${b.lastName || ''}`.trim()
          )
        )
      );
  }, [swimmers, teamId]);

  const activeEvents = useMemo(() => {
    return events
      .filter((event) => event.active !== false)
      .sort((a, b) => Number(a.eventNumber || 0) - Number(b.eventNumber || 0));
  }, [events]);

  const teamEntries = useMemo(() => {
    return entries.filter(
      (entry) =>
        String(entry.teamId || '') === teamId &&
        entry.active !== false &&
        String(entry.status || '').toLowerCase() !== 'scratch'
    );
  }, [entries, teamId]);

  const entryBySwimmerEvent = useMemo(() => {
    const map: Record<string, EntryRow> = {};

    teamEntries.forEach((entry) => {
      const key = `${entry.swimmerId || ''}__${entry.eventId || ''}`;
      map[key] = entry;
    });

    return map;
  }, [teamEntries]);

  const eligibleEventsBySwimmer = useMemo(() => {
    const map: Record<string, EventRow[]> = {};

    teamSwimmers.forEach((swimmer) => {
      const swimmerGender = normalizeGender(swimmer.gender);
      const swimmerAgeGroup = normalizeAgeGroup(swimmer.ageGroup);

      map[swimmer.id] = activeEvents.filter((event) => {
        const eventGender = normalizeGender(event.gender);
        const eventAgeGroup = normalizeAgeGroup(event.ageGroup);

        const genderMatch =
          eventGender === 'mixed' ? true : swimmerGender === eventGender;
        const ageGroupMatch = swimmerAgeGroup === eventAgeGroup;

        return genderMatch && ageGroupMatch;
      });
    });

    return map;
  }, [teamSwimmers, activeEvents]);

  const eligibleSwimmersByEvent = useMemo(() => {
    const map: Record<string, SwimmerRow[]> = {};

    activeEvents.forEach((event) => {
      const eventGender = normalizeGender(event.gender);
      const eventAgeGroup = normalizeAgeGroup(event.ageGroup);

      map[event.id] = teamSwimmers.filter((swimmer) => {
        const swimmerGender = normalizeGender(swimmer.gender);
        const swimmerAgeGroup = normalizeAgeGroup(swimmer.ageGroup);

        const genderMatch =
          eventGender === 'mixed' ? true : swimmerGender === eventGender;
        const ageGroupMatch = swimmerAgeGroup === eventAgeGroup;

        return genderMatch && ageGroupMatch;
      });
    });

    return map;
  }, [activeEvents, teamSwimmers]);

  const filteredSwimmers = useMemo(() => {
    const q = swimmerSearch.trim().toLowerCase();
    if (!q) return teamSwimmers;

    return teamSwimmers.filter((swimmer) => {
      const text = [
        swimmer.fullName || '',
        swimmer.firstName || '',
        swimmer.lastName || '',
        swimmer.gender || '',
        swimmer.ageGroup || '',
      ]
        .join(' ')
        .toLowerCase();

      return text.includes(q);
    });
  }, [teamSwimmers, swimmerSearch]);

  const filteredEvents = useMemo(() => {
    const q = eventSearch.trim().toLowerCase();

    const nonFinalEvents = activeEvents.filter((event) => !isFinalEvent(event));

    if (!q) return nonFinalEvents;

    return nonFinalEvents.filter((event) => {
      const text = [eventDisplayLabel(event), String(event.eventNumber || '')]
        .join(' ')
        .toLowerCase();

      return text.includes(q);
    });
  }, [activeEvents, eventSearch]);

  useEffect(() => {
    setSelectedSwimmerId((prev) => {
      if (prev && filteredSwimmers.some((s) => s.id === prev)) return prev;
      return filteredSwimmers[0]?.id || '';
    });
  }, [filteredSwimmers]);

  useEffect(() => {
    setSelectedEventId((prev) => {
      if (prev && filteredEvents.some((e) => e.id === prev)) return prev;
      return filteredEvents[0]?.id || '';
    });
  }, [filteredEvents]);

  const selectedSwimmer = useMemo(() => {
    return teamSwimmers.find((s) => s.id === selectedSwimmerId) || null;
  }, [teamSwimmers, selectedSwimmerId]);

  const selectedEvent = useMemo(() => {
    return activeEvents.find((e) => e.id === selectedEventId) || null;
  }, [activeEvents, selectedEventId]);

  const selectedSwimmerEvents = useMemo(() => {
    if (!selectedSwimmerId) return [];
    return (eligibleEventsBySwimmer[selectedSwimmerId] || []).filter(
      (event) => !isFinalEvent(event)
    );
  }, [eligibleEventsBySwimmer, selectedSwimmerId]);

  const selectedEventSwimmers = useMemo(() => {
    if (!selectedEventId) return [];
    return eligibleSwimmersByEvent[selectedEventId] || [];
  }, [eligibleSwimmersByEvent, selectedEventId]);

  const summaryRows = useMemo(() => {
    const eventSummaryMap = new Map<
      string,
      {
        eventId: string;
        eventName: string;
        eventNumber: number;
        swimmerCount: number;
      }
    >();

    teamEntries.forEach((entry) => {
      const eventIdKey = String(entry.eventId || '');
      if (!eventIdKey) return;

      const current = eventSummaryMap.get(eventIdKey) || {
        eventId: eventIdKey,
        eventName: entry.eventName || 'Unnamed Event',
        eventNumber: Number(entry.eventNumber || 0),
        swimmerCount: 0,
      };

      current.swimmerCount += 1;
      eventSummaryMap.set(eventIdKey, current);
    });

    return Array.from(eventSummaryMap.values()).sort(
      (a, b) => a.eventNumber - b.eventNumber
    );
  }, [teamEntries]);

  const summaryDetailRows = useMemo(() => {
    const swimmerById: Record<string, SwimmerRow> = {};
    teamSwimmers.forEach((swimmer) => {
      swimmerById[swimmer.id] = swimmer;
    });

    return teamEntries
      .map((entry) => {
        const swimmer = swimmerById[String(entry.swimmerId || '')];
        const category = swimmer?.ageGroup || entry.ageGroup || 'Unspecified';
        const gender = swimmer?.gender || entry.gender || 'Unspecified';

        return {
          entryId: entry.id,
          category,
          gender,
          eventId: entry.eventId || '',
          eventNumber: Number(entry.eventNumber || 0),
          eventName: entry.eventName || 'Unnamed Event',
          swimmerId: entry.swimmerId || '',
          swimmerName:
            swimmer?.fullName || entry.swimmerName || 'Unnamed Swimmer',
        } as SummaryDetailRow;
      })
      .sort((a, b) => {
        const categoryCompare = a.category.localeCompare(b.category);
        if (categoryCompare !== 0) return categoryCompare;

        const genderCompare = normalizeGender(a.gender).localeCompare(
          normalizeGender(b.gender)
        );
        if (genderCompare !== 0) return genderCompare;

        const eventCompare = a.eventNumber - b.eventNumber;
        if (eventCompare !== 0) return eventCompare;

        return a.swimmerName.localeCompare(b.swimmerName);
      });
  }, [teamEntries, teamSwimmers]);

  const summaryCategories = useMemo(() => {
    return Array.from(
      new Set(summaryDetailRows.map((row) => row.category).filter(Boolean))
    );
  }, [summaryDetailRows]);

  useEffect(() => {
    setSelectedSummaryCategory((prev) => {
      if (prev && summaryCategories.includes(prev)) return prev;
      return summaryCategories[0] || '';
    });
  }, [summaryCategories]);

  const summaryRowsForSelectedCategory = useMemo(() => {
    if (!selectedSummaryCategory) return [];
    return summaryDetailRows.filter(
      (row) => row.category === selectedSummaryCategory
    );
  }, [summaryDetailRows, selectedSummaryCategory]);

  const boysSummaryRows = useMemo(() => {
    return summaryRowsForSelectedCategory.filter(
      (row) => normalizeGender(row.gender) === 'boys'
    );
  }, [summaryRowsForSelectedCategory]);

  const girlsSummaryRows = useMemo(() => {
    return summaryRowsForSelectedCategory.filter(
      (row) => normalizeGender(row.gender) === 'girls'
    );
  }, [summaryRowsForSelectedCategory]);

  const mixedSummaryRows = useMemo(() => {
    return summaryRowsForSelectedCategory.filter(
      (row) => normalizeGender(row.gender) === 'mixed'
    );
  }, [summaryRowsForSelectedCategory]);

  const totalEntries = teamEntries.length;
  const totalSwimmers = teamSwimmers.length;

  const handleVerifyPin = () => {
    if (!teamPin?.pin) {
      openModal(
        'No PIN',
        'This team does not have a PIN yet. Please contact the admin.'
      );
      return;
    }

    if (teamPin.active === false) {
      openModal(
        'PIN Inactive',
        'This team PIN is inactive. Please contact the admin.'
      );
      return;
    }

    if (enteredPin.trim() !== String(teamPin.pin || '').trim()) {
      openModal(
        'Invalid PIN',
        'The PIN you entered is not correct. Please try again.'
      );
      return;
    }

    setPinVerified(true);
    setStep('manage');
    openModal('Access Granted', 'Team manager loaded successfully.');
  };

  const toggleEntry = async (
    swimmer: SwimmerRow,
    event: EventRow,
    silent = false
  ) => {
    if (!isEditable) {
      openModal(
        'Editing Disabled',
        'PIN is inactive or not verified. Editing is disabled.'
      );
      return;
    }

    if (!meetId || !teamId) return;

    const existing = entryBySwimmerEvent[`${swimmer.id}__${event.id}`];

    setSaving(true);
    setLoadingMessage(
      existing
        ? `Removing ${swimmer.fullName || 'swimmer'} from ${
            event.name || 'event'
          }...`
        : `Adding ${swimmer.fullName || 'swimmer'} to ${
            event.name || 'event'
          }...`
    );

    try {
      if (existing) {
        await remove(ref(db, `meets/${meetId}/entries/${existing.id}`));
      } else {
        const newEntryRef = push(ref(db, `meets/${meetId}/entries`));

        await set(newEntryRef, {
          swimmerId: swimmer.id,
          swimmerName:
            swimmer.fullName ||
            `${swimmer.firstName || ''} ${swimmer.lastName || ''}`.trim(),
          gender: swimmer.gender || '',
          ageGroup: swimmer.ageGroup || '',
          teamId: swimmer.teamId || teamId,
          teamName: team?.name || swimmer.teamName || swimmer.team || '',
          eventId: event.id,
          eventNumber: event.eventNumber || 0,
          eventName: event.name || '',
          laneSeedTime: '',
          status: 'Entered',
          active: true,
          createdAt: Date.now(),
          createdBy: `team-pin:${teamId}`,
        });
      }

      if (!silent) {
        openModal('Saved', 'Entry updated successfully.');
      }
    } catch (error: any) {
      openModal('Update Failed', error?.message || 'Failed to update entry.');
    } finally {
      setSaving(false);
    }
  };

  const handleGoToSummary = () => {
    setStep('summary');
  };

  const handleBackToManage = () => {
    setStep('manage');
  };

  const handleSubmitTeamReview = async () => {
    if (!isEditable) {
      openModal(
        'Submit Disabled',
        'PIN is inactive or not verified. Submit is disabled.'
      );
      return;
    }

    if (!meetId || !teamId) return;

    setSubmitting(true);
    setLoadingMessage('Submitting final team confirmation...');

    try {
      const eventSummaryPayload: Record<
        string,
        {
          eventId?: string;
          eventName?: string;
          eventNumber?: number;
          swimmerCount?: number;
        }
      > = {};

      summaryRows.forEach((row) => {
        eventSummaryPayload[row.eventId] = {
          eventId: row.eventId,
          eventName: row.eventName,
          eventNumber: row.eventNumber,
          swimmerCount: row.swimmerCount,
        };
      });

      await set(ref(db, `meets/${meetId}/teamEntryReviews/${teamId}`), {
        submitted: true,
        submittedAt: Date.now(),
        submittedByTeamId: teamId,
        teamName: team?.name || '',
        totalSwimmers,
        totalEntries,
        eventSummary: eventSummaryPayload,
      });

      await update(ref(db, `meets/${meetId}/teamPins/${teamId}`), {
        submitted: true,
        lastSubmittedAt: Date.now(),
        updatedAt: Date.now(),
        updatedBy: `team-pin:${teamId}`,
      });

      openModal('Submitted', 'Team entry confirmation submitted successfully.');
    } catch (error: any) {
      openModal(
        'Submit Failed',
        error?.message || 'Failed to submit team review.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handlePrintSummary = () => {
    const allCategories = summaryCategories;

    const buildGenderRows = (rows: SummaryDetailRow[]) =>
      rows
        .map(
          (row) => `
            <tr>
              <td>${row.eventNumber || '—'}</td>
              <td>${row.eventName}</td>
              <td>${row.swimmerName}</td>
            </tr>
          `
        )
        .join('');

    const buildGenderTable = (title: string, rows: SummaryDetailRow[]) => `
      <div class="section-card">
        <div class="section-title">${title}</div>
        ${
          rows.length === 0
            ? `<div class="empty">No entries in this section.</div>`
            : `
              <table>
                <thead>
                  <tr>
                    <th>Event No.</th>
                    <th>Event Name</th>
                    <th>Swimmer</th>
                  </tr>
                </thead>
                <tbody>
                  ${buildGenderRows(rows)}
                </tbody>
              </table>
            `
        }
      </div>
    `;

    const html = allCategories
      .map((category) => {
        const rows = summaryDetailRows.filter(
          (row) => row.category === category
        );
        const boys = rows.filter(
          (row) => normalizeGender(row.gender) === 'boys'
        );
        const girls = rows.filter(
          (row) => normalizeGender(row.gender) === 'girls'
        );
        const mixed = rows.filter(
          (row) => normalizeGender(row.gender) === 'mixed'
        );

        return `
          <div class="category-block">
            <div class="category-title">${category}</div>
            ${buildGenderTable('Boys', boys)}
            ${buildGenderTable('Girls', girls)}
            ${buildGenderTable('Mixed', mixed)}
          </div>
        `;
      })
      .join('');

    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    iframe.setAttribute('aria-hidden', 'true');
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (!doc || !iframe.contentWindow) {
      document.body.removeChild(iframe);
      openModal('Print Failed', 'Unable to prepare the print summary.');
      return;
    }

    doc.open();
    doc.write(`
      <!doctype html>
      <html>
        <head>
          <title>Team Summary</title>
          <style>
            body {
              margin: 0;
              padding: 24px;
              font-family: Arial, sans-serif;
              color: #14253d;
              background: #ffffff;
            }
            .header {
              display: flex;
              align-items: center;
              gap: 16px;
              border-bottom: 3px solid #d4af37;
              padding-bottom: 16px;
              margin-bottom: 24px;
            }
            .logo {
              width: 64px;
              height: 64px;
              object-fit: contain;
            }
            .title {
              font-size: 26px;
              font-weight: 800;
              color: #0b1f3a;
            }
            .sub {
              margin-top: 4px;
              color: #5b6b7d;
              font-size: 14px;
            }
            .stats {
              display: flex;
              gap: 16px;
              flex-wrap: wrap;
              margin-bottom: 24px;
            }
            .stat {
              border: 1px solid #d9dee5;
              border-radius: 12px;
              padding: 12px 16px;
              min-width: 140px;
            }
            .stat-value {
              font-size: 22px;
              font-weight: 800;
              color: #b89018;
            }
            .stat-label {
              color: #5b6b7d;
              margin-top: 4px;
              font-size: 13px;
            }
            .category-block {
              margin-bottom: 28px;
              page-break-inside: avoid;
            }
            .category-title {
              background: #0b1f3a;
              color: #ffffff;
              padding: 10px 14px;
              border-radius: 10px;
              font-weight: 800;
              margin-bottom: 14px;
            }
            .section-card {
              border: 1px solid #d9dee5;
              border-radius: 12px;
              padding: 14px;
              margin-bottom: 14px;
            }
            .section-title {
              font-size: 18px;
              font-weight: 700;
              color: #0b1f3a;
              margin-bottom: 10px;
            }
            .empty {
              color: #6f7d8c;
              font-style: italic;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border-bottom: 1px solid #e4e8ee;
              padding: 10px 12px;
              text-align: left;
              font-size: 14px;
            }
            th {
              color: #b89018;
              font-weight: 800;
            }
            @media print {
              body {
                padding: 16px;
              }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <img class="logo" src="${PANTHERS_LOGO}" alt="Panthers logo" />
            <div>
              <div class="title">Panthers Team Summary</div>
              <div class="sub">${meet?.name || 'Meet'} • ${
      team?.name || 'Team'
    } • ${team?.seedClub || 'Seed Club'}</div>
            </div>
          </div>
  
          <div class="stats">
            <div class="stat">
              <div class="stat-value">${totalSwimmers}</div>
              <div class="stat-label">Total Swimmers</div>
            </div>
            <div class="stat">
              <div class="stat-value">${totalEntries}</div>
              <div class="stat-label">Total Entries</div>
            </div>
            <div class="stat">
              <div class="stat-value">${summaryRows.length}</div>
              <div class="stat-label">Events with Entries</div>
            </div>
            <div class="stat">
              <div class="stat-value">${
                teamReview?.submitted ? 'Yes' : 'No'
              }</div>
              <div class="stat-label">Submitted</div>
            </div>
          </div>
  
          ${html}
        </body>
      </html>
    `);
    doc.close();

    iframe.onload = () => {
      setTimeout(() => {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();

        setTimeout(() => {
          document.body.removeChild(iframe);
        }, 1000);
      }, 300);
    };
  };

  const renderSummaryGenderTable = (
    title: string,
    rows: SummaryDetailRow[]
  ) => {
    return (
      <div style={cardStyle}>
        <div style={{ ...cardTitleStyle, marginBottom: 12 }}>{title}</div>

        {rows.length === 0 ? (
          <div style={noteStyle}>No entries in this section.</div>
        ) : (
          <div style={tableWrapStyle}>
            <table style={summaryDetailTableStyle}>
              <thead>
                <tr>
                  <th style={thStyle}>Event No.</th>
                  <th style={thStyle}>Event Name</th>
                  <th style={thStyle}>Swimmer</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.entryId}>
                    <td style={tdStyle}>{row.eventNumber || '—'}</td>
                    <td style={tdStyle}>{row.eventName}</td>
                    <td style={tdStyle}>{row.swimmerName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    );
  };

  return (
    <div style={pageStyle}>
      {(pageLoading || saving || submitting) && (
        <div style={loadingOverlayStyle}>
          <div style={loadingCardStyle}>
            <div style={logoWrapStyle}>
              <img
                src={PANTHERS_LOGO}
                alt="Panthers logo"
                style={logoImageStyle}
              />
              <div>
                <div style={loadingTitleStyle}>Panthers Team Manager</div>
                <div style={loadingSubStyle}>{loadingMessage}</div>
              </div>
            </div>

            <div style={spinnerStyle} />
          </div>
        </div>
      )}

      {modalOpen && (
        <div style={modalBackdropStyle}>
          <div style={modalCardStyle}>
            <div style={modalHeaderStyle}>
              <img
                src={PANTHERS_LOGO}
                alt="Panthers logo"
                style={logoMiniImageStyle}
              />
              <div>
                <div style={modalTitleStyle}>{modalTitle}</div>
                <div style={modalSubStyle}>Panthers Team Manager</div>
              </div>
            </div>

            <div style={modalBodyStyle}>{modalMessage}</div>

            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button onClick={closeModal} style={primaryBtnStyle}>
                OK
              </button>
            </div>
          </div>
        </div>
      )}

      <div style={heroStyle}>
        <div style={heroLeftStyle}>
          <img src={PANTHERS_LOGO} alt="Panthers logo" style={heroLogoStyle} />
          <div>
            <div style={heroTitleStyle}>Panthers Team Manager</div>
            <div style={heroSubStyle}>
              {meet?.name || 'Meet'} • {team?.name || 'Team'} •{' '}
              {team?.seedClub || 'Seed Club'}
            </div>
          </div>
        </div>

        <div style={statusWrapStyle}>
          <span
            style={{
              ...statusPillStyle,
              background: isPinActive
                ? 'rgba(46,175,109,0.18)'
                : 'rgba(217,83,79,0.18)',
              border: isPinActive
                ? '1px solid rgba(46,175,109,0.35)'
                : '1px solid rgba(217,83,79,0.35)',
              color: isPinActive ? '#d7ffe8' : '#ffd6d3',
            }}
          >
            {isPinActive ? 'PIN Active' : 'PIN Inactive'}
          </span>

          <span style={statusPillStyle}>
            Submitted: {teamReview?.submitted ? 'Yes' : 'No'}
          </span>
        </div>
      </div>

      <div style={panelStyle}>
        {!meetId || !teamId ? (
          <p style={noteStyle}>
            Invalid team link. Please use the full team link shared by the
            admin.
          </p>
        ) : !team ? (
          <p style={noteStyle}>Team not found.</p>
        ) : step === 'pin' ? (
          <div style={{ display: 'grid', gap: 16, maxWidth: 460 }}>
            <h2 style={{ margin: 0 }}>Manager PIN Access</h2>
            <p style={noteStyle}>
              Enter the team PIN shared by the admin to open the team manager.
            </p>

            <div>
              <label style={labelStyle}>Enter PIN</label>
              <input
                value={enteredPin}
                onChange={(e) =>
                  setEnteredPin(e.target.value.replace(/\D/g, '').slice(0, 6))
                }
                placeholder="Enter PIN"
                style={inputStyle}
              />
            </div>

            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <button onClick={handleVerifyPin} style={primaryBtnStyle}>
                Verify PIN
              </button>
            </div>
          </div>
        ) : step === 'manage' ? (
          <div style={{ display: 'grid', gap: 20 }}>
            <div style={summaryHeaderStyle}>
              <div>
                <h2 style={{ margin: 0 }}>Manage Entries</h2>
                <div style={noteStyle}>
                  Choose how you want to enter: by swimmer name or by event.
                </div>
              </div>

              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                <button
                  onClick={() => setManageMode('BY_NAME')}
                  style={
                    manageMode === 'BY_NAME'
                      ? primaryBtnStyle
                      : secondaryBtnStyle
                  }
                >
                  Enter by Name
                </button>

                <button
                  onClick={() => setManageMode('BY_EVENT')}
                  style={
                    manageMode === 'BY_EVENT'
                      ? primaryBtnStyle
                      : secondaryBtnStyle
                  }
                >
                  Enter by Event
                </button>

                <button onClick={handleGoToSummary} style={secondaryBtnStyle}>
                  View Summary
                </button>
              </div>
            </div>

            {teamSwimmers.length === 0 ? (
              <p style={noteStyle}>No swimmers found for this team.</p>
            ) : manageMode === 'BY_NAME' ? (
              <>
                <div style={filterGridStyle}>
                  <div>
                    <label style={labelStyle}>Search Swimmer</label>
                    <input
                      value={swimmerSearch}
                      onChange={(e) => setSwimmerSearch(e.target.value)}
                      placeholder="Search by swimmer, category, gender..."
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label style={labelStyle}>Choose Swimmer</label>
                    <select
                      value={selectedSwimmerId}
                      onChange={(e) => setSelectedSwimmerId(e.target.value)}
                      style={inputStyle}
                    >
                      {filteredSwimmers.length === 0 ? (
                        <option value="">No swimmers found</option>
                      ) : (
                        filteredSwimmers.map((swimmer) => (
                          <option key={swimmer.id} value={swimmer.id}>
                            {swimmerDisplayLabel(swimmer)}
                          </option>
                        ))
                      )}
                    </select>
                  </div>
                </div>

                {selectedSwimmer ? (
                  <div style={cardStyle}>
                    <div style={cardHeaderStyle}>
                      <div>
                        <div style={cardTitleStyle}>
                          {selectedSwimmer.fullName ||
                            `${selectedSwimmer.firstName || ''} ${
                              selectedSwimmer.lastName || ''
                            }`.trim() ||
                            'Unnamed Swimmer'}
                        </div>
                        <div style={cardSubStyle}>
                          {selectedSwimmer.ageGroup || '—'} •{' '}
                          {displayGenderLabel(selectedSwimmer.gender)}
                        </div>
                      </div>
                    </div>

                    {selectedSwimmerEvents.length === 0 ? (
                      <p style={noteStyle}>
                        No eligible events for this swimmer.
                      </p>
                    ) : (
                      <div style={tableWrapStyle}>
                        <table style={managerTableStyle}>
                          <thead>
                            <tr>
                              <th style={thStyle}>Select</th>
                              <th style={thStyle}>Event No.</th>
                              <th style={thStyle}>Event</th>
                              <th style={thStyle}>Gender</th>
                              <th style={thStyle}>Age Group</th>
                            </tr>
                          </thead>
                          <tbody>
                            {selectedSwimmerEvents.map((event) => {
                              const existingEntry =
                                entryBySwimmerEvent[
                                  `${selectedSwimmer.id}__${event.id}`
                                ];
                              const checked = !!existingEntry;

                              return (
                                <tr key={event.id}>
                                  <td style={tdStyle}>
                                    <input
                                      type="checkbox"
                                      checked={checked}
                                      disabled={!isEditable || saving}
                                      onChange={() =>
                                        toggleEntry(
                                          selectedSwimmer,
                                          event,
                                          true
                                        )
                                      }
                                    />
                                  </td>
                                  <td style={tdStyle}>
                                    {event.eventNumber || '—'}
                                  </td>
                                  <td style={tdStyle}>
                                    {eventDisplayLabel(event)}
                                  </td>
                                  <td style={tdStyle}>
                                    {displayGenderLabel(event.gender)}
                                  </td>
                                  <td style={tdStyle}>
                                    {event.ageGroup || '—'}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                ) : (
                  <p style={noteStyle}>Please choose a swimmer.</p>
                )}
              </>
            ) : (
              <>
                <div style={filterGridStyle}>
                  <div>
                    <label style={labelStyle}>Search Event</label>
                    <input
                      value={eventSearch}
                      onChange={(e) => setEventSearch(e.target.value)}
                      placeholder="Search by event, gender, age group..."
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label style={labelStyle}>Choose Event</label>
                    <select
                      value={selectedEventId}
                      onChange={(e) => setSelectedEventId(e.target.value)}
                      style={inputStyle}
                    >
                      {filteredEvents.length === 0 ? (
                        <option value="">No events found</option>
                      ) : (
                        filteredEvents.map((event) => (
                          <option key={event.id} value={event.id}>
                            {eventDisplayLabel(event)}
                          </option>
                        ))
                      )}
                    </select>
                  </div>
                </div>

                {selectedEvent ? (
                  <div style={cardStyle}>
                    <div style={cardHeaderStyle}>
                      <div>
                        <div style={cardTitleStyle}>
                          {eventDisplayLabel(selectedEvent)}
                        </div>
                      </div>
                    </div>

                    {selectedEventSwimmers.length === 0 ? (
                      <p style={noteStyle}>
                        No eligible swimmers for this event.
                      </p>
                    ) : (
                      <div style={tableWrapStyle}>
                        <table style={managerTableStyle}>
                          <thead>
                            <tr>
                              <th style={thStyle}>Select</th>
                              <th style={thStyle}>Swimmer</th>
                              <th style={thStyle}>Gender</th>
                              <th style={thStyle}>Age Group</th>
                            </tr>
                          </thead>
                          <tbody>
                            {selectedEventSwimmers.map((swimmer) => {
                              const existingEntry =
                                entryBySwimmerEvent[
                                  `${swimmer.id}__${selectedEvent.id}`
                                ];
                              const checked = !!existingEntry;

                              return (
                                <tr key={swimmer.id}>
                                  <td style={tdStyle}>
                                    <input
                                      type="checkbox"
                                      checked={checked}
                                      disabled={!isEditable || saving}
                                      onChange={() =>
                                        toggleEntry(
                                          swimmer,
                                          selectedEvent,
                                          true
                                        )
                                      }
                                    />
                                  </td>
                                  <td style={tdStyle}>
                                    {swimmer.fullName ||
                                      `${swimmer.firstName || ''} ${
                                        swimmer.lastName || ''
                                      }`.trim() ||
                                      'Unnamed Swimmer'}
                                  </td>
                                  <td style={tdStyle}>
                                    {displayGenderLabel(swimmer.gender)}
                                  </td>
                                  <td style={tdStyle}>
                                    {swimmer.ageGroup || '—'}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                ) : (
                  <p style={noteStyle}>Please choose an event.</p>
                )}
              </>
            )}
          </div>
        ) : (
          <div style={{ display: 'grid', gap: 20 }}>
            <div style={summaryHeaderStyle}>
              <div>
                <h2 style={{ margin: 0 }}>Entry Summary and Report</h2>
                <div style={noteStyle}>
                  Review by category, then check swimmers listed against each
                  event before final submission.
                </div>
              </div>

              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                <button onClick={handleBackToManage} style={secondaryBtnStyle}>
                  Back to Entries
                </button>

                <button onClick={handlePrintSummary} style={secondaryBtnStyle}>
                  Print Summary
                </button>

                <button
                  onClick={handleSubmitTeamReview}
                  style={primaryBtnStyle}
                  disabled={!isEditable || submitting}
                >
                  {submitting ? 'Submitting...' : 'Submit Final Confirmation'}
                </button>
              </div>
            </div>

            <div style={statsGridStyle}>
              <div style={statCardStyle}>
                <div style={statValueStyle}>{totalSwimmers}</div>
                <div style={statLabelStyle}>Total Swimmers</div>
              </div>

              <div style={statCardStyle}>
                <div style={statValueStyle}>{totalEntries}</div>
                <div style={statLabelStyle}>Total Entries</div>
              </div>

              <div style={statCardStyle}>
                <div style={statValueStyle}>{summaryRows.length}</div>
                <div style={statLabelStyle}>Events with Entries</div>
              </div>

              <div style={statCardStyle}>
                <div style={statValueStyle}>
                  {teamReview?.submitted ? 'Yes' : 'No'}
                </div>
                <div style={statLabelStyle}>Already Submitted</div>
              </div>
            </div>

            <div style={cardStyle}>
              <h3 style={{ marginTop: 0, marginBottom: 14 }}>Category Tabs</h3>

              {summaryCategories.length === 0 ? (
                <p style={noteStyle}>No entries available for summary.</p>
              ) : (
                <>
                  <div style={tabsWrapStyle}>
                    {summaryCategories.map((category) => (
                      <button
                        key={category}
                        onClick={() => setSelectedSummaryCategory(category)}
                        style={
                          selectedSummaryCategory === category
                            ? activeTabBtnStyle
                            : tabBtnStyle
                        }
                      >
                        {category}
                      </button>
                    ))}
                  </div>

                  <div style={{ display: 'grid', gap: 16, marginTop: 16 }}>
                    {renderSummaryGenderTable('Boys', boysSummaryRows)}
                    {renderSummaryGenderTable('Girls', girlsSummaryRows)}
                    {renderSummaryGenderTable('Mixed', mixedSummaryRows)}
                  </div>
                </>
              )}
            </div>

            <div style={cardStyle}>
              <h3 style={{ marginTop: 0 }}>Submission Status</h3>
              <div style={noteStyle}>
                Last Submitted:{' '}
                {formatDateTime(
                  teamReview?.submittedAt || teamPin?.lastSubmittedAt
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const pageStyle: CSSProperties = {
  minHeight: '100vh',
  background: '#071426',
  color: 'white',
  padding: 24,
  boxSizing: 'border-box',
};

const heroStyle: CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  gap: 16,
  flexWrap: 'wrap',
  alignItems: 'center',
  marginBottom: 20,
};

const heroLeftStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 14,
};

const heroLogoStyle: CSSProperties = {
  width: 64,
  height: 64,
  objectFit: 'contain',
  borderRadius: 14,
  background: 'rgba(255,255,255,0.08)',
  padding: 6,
  boxShadow: '0 8px 18px rgba(0,0,0,0.28)',
};

const logoImageStyle: CSSProperties = {
  width: 52,
  height: 52,
  objectFit: 'contain',
  borderRadius: 12,
  background: 'rgba(255,255,255,0.08)',
  padding: 4,
};

const logoMiniImageStyle: CSSProperties = {
  width: 42,
  height: 42,
  objectFit: 'contain',
  borderRadius: 10,
  background: 'rgba(255,255,255,0.08)',
  padding: 4,
};

const heroTitleStyle: CSSProperties = {
  fontSize: 28,
  fontWeight: 800,
};

const heroSubStyle: CSSProperties = {
  color: '#9fb3c8',
  marginTop: 4,
};

const loadingOverlayStyle: CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(3, 12, 24, 0.72)',
  backdropFilter: 'blur(8px)',
  zIndex: 5000,
  display: 'grid',
  placeItems: 'center',
  padding: 24,
};

const loadingCardStyle: CSSProperties = {
  width: '100%',
  maxWidth: 520,
  background: 'rgba(11,31,58,0.95)',
  border: '1px solid rgba(255,255,255,0.10)',
  borderRadius: 20,
  padding: 24,
  boxShadow: '0 20px 60px rgba(0,0,0,0.32)',
};

const logoWrapStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 14,
};

const loadingTitleStyle: CSSProperties = {
  fontWeight: 800,
  fontSize: 20,
};

const loadingSubStyle: CSSProperties = {
  marginTop: 4,
  color: '#9fb3c8',
};

const spinnerStyle: CSSProperties = {
  width: 22,
  height: 22,
  borderRadius: '50%',
  border: '3px solid rgba(255,255,255,0.22)',
  borderTopColor: '#d4af37',
  marginTop: 18,
  animation: 'panthers-spin 0.8s linear infinite',
};

const modalBackdropStyle: CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(3, 12, 24, 0.72)',
  backdropFilter: 'blur(6px)',
  zIndex: 5100,
  display: 'grid',
  placeItems: 'center',
  padding: 24,
};

const modalCardStyle: CSSProperties = {
  width: '100%',
  maxWidth: 480,
  background: 'rgba(11,31,58,0.98)',
  border: '1px solid rgba(255,255,255,0.10)',
  borderRadius: 20,
  padding: 22,
  boxShadow: '0 20px 60px rgba(0,0,0,0.35)',
};

const modalHeaderStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 12,
  marginBottom: 12,
};

const modalTitleStyle: CSSProperties = {
  fontSize: 20,
  fontWeight: 800,
};

const modalSubStyle: CSSProperties = {
  color: '#9fb3c8',
  fontSize: 13,
  marginTop: 2,
};

const modalBodyStyle: CSSProperties = {
  color: '#f5f7fb',
  lineHeight: 1.5,
  marginBottom: 18,
};

const statusWrapStyle: CSSProperties = {
  display: 'flex',
  gap: 10,
  flexWrap: 'wrap',
};

const statusPillStyle: CSSProperties = {
  padding: '8px 12px',
  borderRadius: 999,
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.08)',
  fontSize: 13,
  fontWeight: 700,
};

const panelStyle: CSSProperties = {
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 18,
  padding: 20,
};

const labelStyle: CSSProperties = {
  display: 'block',
  marginBottom: 8,
};

const inputStyle: CSSProperties = {
  width: '100%',
  padding: '12px 14px',
  borderRadius: 12,
  border: '1px solid rgba(255,255,255,0.12)',
  background: 'rgba(255,255,255,0.06)',
  color: 'white',
  outline: 'none',
  boxSizing: 'border-box',
};

const primaryBtnStyle: CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: 'none',
  background: '#d4af37',
  color: '#071426',
  fontWeight: 700,
  cursor: 'pointer',
};

const secondaryBtnStyle: CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: '1px solid rgba(255,255,255,0.12)',
  background: 'rgba(255,255,255,0.04)',
  color: 'white',
  fontWeight: 700,
  cursor: 'pointer',
};

const noteStyle: CSSProperties = {
  color: '#9fb3c8',
};

const summaryHeaderStyle: CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  gap: 12,
  flexWrap: 'wrap',
  alignItems: 'center',
};

const filterGridStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'minmax(260px, 1fr) minmax(260px, 1fr)',
  gap: 14,
};

const cardStyle: CSSProperties = {
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 16,
  padding: 16,
  background: 'rgba(255,255,255,0.03)',
};

const cardHeaderStyle: CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  gap: 12,
  flexWrap: 'wrap',
  alignItems: 'center',
  marginBottom: 12,
};

const cardTitleStyle: CSSProperties = {
  fontSize: 18,
  fontWeight: 700,
};

const cardSubStyle: CSSProperties = {
  color: '#9fb3c8',
  marginTop: 4,
};

const statsGridStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
  gap: 12,
};

const statCardStyle: CSSProperties = {
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 16,
  padding: 16,
  background: 'rgba(255,255,255,0.03)',
};

const statValueStyle: CSSProperties = {
  fontSize: 28,
  fontWeight: 800,
  color: '#f1d67a',
};

const statLabelStyle: CSSProperties = {
  color: '#9fb3c8',
  marginTop: 6,
};

const tableWrapStyle: CSSProperties = {
  overflowX: 'auto',
};

const managerTableStyle: CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  minWidth: 700,
};

const summaryDetailTableStyle: CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  minWidth: 520,
};

const tabsWrapStyle: CSSProperties = {
  display: 'flex',
  gap: 12,
  flexWrap: 'wrap',
};

const tabBtnStyle: CSSProperties = {
  minWidth: 140,
  padding: '12px 22px',
  borderRadius: 14,
  border: '1px solid rgba(255,255,255,0.14)',
  background: 'rgba(255,255,255,0.05)',
  color: 'white',
  fontWeight: 800,
  cursor: 'pointer',
  boxShadow: '0 8px 18px rgba(0,0,0,0.14)',
};

const activeTabBtnStyle: CSSProperties = {
  minWidth: 140,
  padding: '12px 22px',
  borderRadius: 14,
  border: '1px solid rgba(212,175,55,0.55)',
  background:
    'linear-gradient(180deg, rgba(212,175,55,0.28) 0%, rgba(184,144,24,0.22) 100%)',
  color: '#ffe89a',
  fontWeight: 800,
  cursor: 'pointer',
  boxShadow: '0 10px 22px rgba(0,0,0,0.18)',
};

const thStyle: CSSProperties = {
  textAlign: 'left',
  padding: '12px 14px',
  fontSize: 13,
  color: '#f1d67a',
  borderBottom: '1px solid rgba(255,255,255,0.08)',
  whiteSpace: 'nowrap',
};

const tdStyle: CSSProperties = {
  padding: '12px 14px',
  borderBottom: '1px solid rgba(255,255,255,0.06)',
  verticalAlign: 'top',
};
