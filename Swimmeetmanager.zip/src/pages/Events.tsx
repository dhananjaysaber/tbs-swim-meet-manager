import { useEffect, useMemo, useState } from 'react';
import { push, ref, set, onValue, update, remove } from 'firebase/database';
import { auth } from '../firebase/auth.js';
import { db } from '../firebase/db.js';
import AppShell from '../components/AppShell';

type MeetRow = {
  id: string;
  name?: string;
  venue?: string;
  date?: string;
  laneCount?: number;
  settings?: {
    categories?: Record<string, string>;
  };
};

type EventRound = 'Heats' | 'Final' | 'Timed Final';

type EventRow = {
  id: string;
  eventNumber?: number;
  distance?: string;
  stroke?: string;
  gender?: string;
  ageGroup?: string;
  eventType?: string;
  round?: EventRound;
  qualifiesToEventId?: string;
  qualifyCount?: number;
  relay?: boolean;
  name?: string;
  active?: boolean;
  createdAt?: number;
  createdBy?: string;
};

const strokeOptions = [
  'Freestyle',
  'Backstroke',
  'Breaststroke',
  'Butterfly',
  'Individual Medley',
  'Medley Relay',
  'Freestyle Relay',
];

const genderOptions = ['Boys', 'Girls', 'Mixed'];
const eventTypeOptions = ['Individual', 'Relay'];
const roundOptions: EventRound[] = ['Heats', 'Final', 'Timed Final'];

export default function Events() {
  const [activeMeetId, setActiveMeetId] = useState('');
  const [activeMeet, setActiveMeet] = useState<MeetRow | null>(null);
  const [meetCategories, setMeetCategories] = useState<string[]>([]);

  const [eventNumber, setEventNumber] = useState('');
  const [distance, setDistance] = useState('');
  const [stroke, setStroke] = useState('Freestyle');
  const [gender, setGender] = useState('Boys');
  const [ageGroup, setAgeGroup] = useState('');
  const [eventType, setEventType] = useState('Individual');
  const [round, setRound] = useState<EventRound>('Heats');
  const [qualifiesToEventId, setQualifiesToEventId] = useState('');
  const [qualifyCount, setQualifyCount] = useState('');
  const [active, setActive] = useState(true);

  const [events, setEvents] = useState<EventRow[]>([]);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  const [editingEventId, setEditingEventId] = useState('');
  const [editEventNumber, setEditEventNumber] = useState('');
  const [editDistance, setEditDistance] = useState('');
  const [editStroke, setEditStroke] = useState('Freestyle');
  const [editGender, setEditGender] = useState('Boys');
  const [editAgeGroup, setEditAgeGroup] = useState('');
  const [editEventType, setEditEventType] = useState('Individual');
  const [editRound, setEditRound] = useState<EventRound>('Heats');
  const [editQualifiesToEventId, setEditQualifiesToEventId] = useState('');
  const [editQualifyCount, setEditQualifyCount] = useState('');
  const [editActive, setEditActive] = useState(true);
  const [updatingEventId, setUpdatingEventId] = useState('');

  const meetLaneCount = Number(activeMeet?.laneCount || 0);

  const sortedEvents = useMemo(() => {
    return [...events].sort((a, b) => {
      const numA = Number(a.eventNumber || 0);
      const numB = Number(b.eventNumber || 0);

      if (numA !== numB) return numA - numB;

      const roundOrder = (value?: string) => {
        if (value === 'Heats') return 1;
        if (value === 'Final') return 2;
        if (value === 'Timed Final') return 3;
        return 99;
      };

      const roundDiff = roundOrder(a.round) - roundOrder(b.round);
      if (roundDiff !== 0) return roundDiff;

      return String(a.name || '').localeCompare(String(b.name || ''));
    });
  }, [events]);

  const finalEventOptions = useMemo(() => {
    return [...events]
      .filter((event) => event.active !== false && event.round === 'Final')
      .sort((a, b) => Number(a.eventNumber || 0) - Number(b.eventNumber || 0));
  }, [events]);

  useEffect(() => {
    const activeRef = ref(db, 'appState/activeMeetId');

    const unsub = onValue(activeRef, (snap) => {
      setActiveMeetId(snap.val() || '');
    });

    return () => unsub();
  }, []);

  useEffect(() => {
    if (!activeMeetId) {
      setActiveMeet(null);
      setMeetCategories([]);
      setAgeGroup('');
      setEditAgeGroup('');
      return;
    }

    const meetRef = ref(db, `meets/${activeMeetId}`);

    const unsub = onValue(meetRef, (snap) => {
      if (!snap.exists()) {
        setActiveMeet(null);
        setMeetCategories([]);
        setAgeGroup('');
        setEditAgeGroup('');
        return;
      }

      const meetData = snap.val();

      setActiveMeet({
        id: activeMeetId,
        ...meetData,
      });

      const categoriesObj = meetData?.settings?.categories || {};
      const categories = Object.values(categoriesObj).filter(Boolean) as string[];
      setMeetCategories(categories);

      setAgeGroup((prev) => {
        if (prev && categories.includes(prev)) return prev;
        return categories[0] || '';
      });

      setEditAgeGroup((prev) => {
        if (prev && categories.includes(prev)) return prev;
        return categories[0] || '';
      });
    });

    return () => unsub();
  }, [activeMeetId]);

  useEffect(() => {
    if (!activeMeetId) {
      setEvents([]);
      return;
    }

    const eventsRef = ref(db, `meets/${activeMeetId}/events`);

    const unsub = onValue(eventsRef, (snap) => {
      const val = snap.val();

      if (!val) {
        setEvents([]);
        return;
      }

      const rows: EventRow[] = Object.entries(val).map(([id, item]: any) => ({
        id,
        ...item,
      }));

      setEvents(rows);
    });

    return () => unsub();
  }, [activeMeetId]);

  useEffect(() => {
    if (round === 'Heats') {
      if (!qualifyCount && meetLaneCount > 0) {
        setQualifyCount(String(meetLaneCount));
      }
    } else {
      setQualifiesToEventId('');
      setQualifyCount('');
    }
  }, [round, meetLaneCount, qualifyCount]);

  useEffect(() => {
    if (editRound === 'Heats') {
      if (!editQualifyCount && meetLaneCount > 0) {
        setEditQualifyCount(String(meetLaneCount));
      }
    } else {
      setEditQualifiesToEventId('');
      setEditQualifyCount('');
    }
  }, [editRound, meetLaneCount, editQualifyCount]);

  const buildEventName = (
    distanceValue: string,
    strokeValue: string,
    genderValue: string,
    ageGroupValue: string,
    eventTypeValue: string,
    roundValue: EventRound
  ) => {
    const relayLabel = eventTypeValue === 'Relay' ? ' Relay' : '';
    return `${distanceValue}m ${strokeValue}${relayLabel} - ${genderValue} - ${ageGroupValue} - ${roundValue}`;
  };

  const getEventDisplayLabel = (event: EventRow) => {
    return `Event ${event.eventNumber || '—'} • ${event.name || 'Unnamed Event'}`;
  };

  const resetForm = () => {
    setEventNumber('');
    setDistance('');
    setStroke('Freestyle');
    setGender('Boys');
    setAgeGroup(meetCategories[0] || '');
    setEventType('Individual');
    setRound('Heats');
    setQualifiesToEventId('');
    setQualifyCount(meetLaneCount > 0 ? String(meetLaneCount) : '');
    setActive(true);
  };

  const validateHeatsFields = (
    currentRound: EventRound,
    currentQualifiesToEventId: string,
    currentQualifyCount: string
  ) => {
    if (currentRound !== 'Heats') return null;

    if (!currentQualifiesToEventId.trim()) {
      return 'Please select the Final event this Heats event qualifies to';
    }

    if (!currentQualifyCount.trim()) {
      return 'Please enter qualify count';
    }

    const parsed = Number(currentQualifyCount);
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return 'Qualify count must be a valid number greater than 0';
    }

    return null;
  };

  const handleSaveEvent = async () => {
    if (!activeMeetId) {
      setMsg('Please select an active meet first from the Meets page');
      return;
    }

    if (!eventNumber.trim()) {
      setMsg('Please enter event number');
      return;
    }

    if (!distance.trim()) {
      setMsg('Please enter distance');
      return;
    }

    if (!ageGroup.trim()) {
      setMsg('Please select category / age group');
      return;
    }

    const heatsValidation = validateHeatsFields(round, qualifiesToEventId, qualifyCount);
    if (heatsValidation) {
      setMsg(heatsValidation);
      return;
    }

    const duplicateEventNumber = events.find(
      (event) => String(event.eventNumber || '') === eventNumber.trim()
    );

    if (duplicateEventNumber) {
      setMsg('An event with this event number already exists in the active meet');
      return;
    }

    const name = buildEventName(
      distance.trim(),
      stroke,
      gender,
      ageGroup,
      eventType,
      round
    );

    const duplicateName = events.find(
      (event) =>
        String(event.name || '').trim().toLowerCase() === name.trim().toLowerCase()
    );

    if (duplicateName) {
      setMsg('This event already exists in the active meet');
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      setMsg('You are not logged in');
      return;
    }

    setSaving(true);
    setMsg('Saving event...');

    try {
      const newEventRef = push(ref(db, `meets/${activeMeetId}/events`));

      await set(newEventRef, {
        eventNumber: Number(eventNumber),
        distance: distance.trim(),
        stroke,
        gender,
        ageGroup,
        eventType,
        round,
        qualifiesToEventId: round === 'Heats' ? qualifiesToEventId : '',
        qualifyCount: round === 'Heats' ? Number(qualifyCount) : 0,
        relay: eventType === 'Relay',
        name,
        active,
        createdAt: Date.now(),
        createdBy: user.uid,
      });

      setMsg('Event saved successfully');
      resetForm();
    } catch (error: any) {
      setMsg(error.message || 'Failed to save event');
    } finally {
      setSaving(false);
    }
  };

  const handleStartEdit = (event: EventRow) => {
    setEditingEventId(event.id);
    setEditEventNumber(String(event.eventNumber || ''));
    setEditDistance(String(event.distance || ''));
    setEditStroke(String(event.stroke || 'Freestyle'));
    setEditGender(String(event.gender || 'Boys'));
    setEditAgeGroup(String(event.ageGroup || meetCategories[0] || ''));
    setEditEventType(String(event.eventType || 'Individual'));
    setEditRound((event.round as EventRound) || 'Heats');
    setEditQualifiesToEventId(String(event.qualifiesToEventId || ''));
    setEditQualifyCount(
      event.round === 'Heats'
        ? String(event.qualifyCount || meetLaneCount || '')
        : ''
    );
    setEditActive(event.active !== false);
  };

  const handleCancelEdit = () => {
    setEditingEventId('');
    setEditEventNumber('');
    setEditDistance('');
    setEditStroke('Freestyle');
    setEditGender('Boys');
    setEditAgeGroup('');
    setEditEventType('Individual');
    setEditRound('Heats');
    setEditQualifiesToEventId('');
    setEditQualifyCount('');
    setEditActive(true);
  };

  const handleUpdateEvent = async (eventId: string) => {
    if (!editEventNumber.trim()) {
      setMsg('Please enter event number');
      return;
    }

    if (!editDistance.trim()) {
      setMsg('Please enter distance');
      return;
    }

    if (!editAgeGroup.trim()) {
      setMsg('Please select category / age group');
      return;
    }

    const heatsValidation = validateHeatsFields(
      editRound,
      editQualifiesToEventId,
      editQualifyCount
    );
    if (heatsValidation) {
      setMsg(heatsValidation);
      return;
    }

    const duplicateEventNumber = events.find(
      (event) =>
        event.id !== eventId &&
        String(event.eventNumber || '') === editEventNumber.trim()
    );

    if (duplicateEventNumber) {
      setMsg('Another event with this event number already exists');
      return;
    }

    const name = buildEventName(
      editDistance.trim(),
      editStroke,
      editGender,
      editAgeGroup,
      editEventType,
      editRound
    );

    const duplicateName = events.find(
      (event) =>
        event.id !== eventId &&
        String(event.name || '').trim().toLowerCase() === name.trim().toLowerCase()
    );

    if (duplicateName) {
      setMsg('Another event with the same setup already exists');
      return;
    }

    setUpdatingEventId(eventId);
    setMsg('Updating event...');

    try {
      await update(ref(db, `meets/${activeMeetId}/events/${eventId}`), {
        eventNumber: Number(editEventNumber),
        distance: editDistance.trim(),
        stroke: editStroke,
        gender: editGender,
        ageGroup: editAgeGroup,
        eventType: editEventType,
        round: editRound,
        qualifiesToEventId: editRound === 'Heats' ? editQualifiesToEventId : '',
        qualifyCount: editRound === 'Heats' ? Number(editQualifyCount) : 0,
        relay: editEventType === 'Relay',
        name,
        active: editActive,
      });

      setMsg('Event updated successfully');
      handleCancelEdit();
    } catch (error: any) {
      setMsg(error.message || 'Failed to update event');
    } finally {
      setUpdatingEventId('');
    }
  };

  const handleToggleEventActive = async (event: EventRow) => {
    try {
      const nextValue = !event.active;
      await update(ref(db, `meets/${activeMeetId}/events/${event.id}`), {
        active: nextValue,
      });
      setMsg(nextValue ? 'Event activated' : 'Event marked inactive');
    } catch (error: any) {
      setMsg(error.message || 'Failed to update event status');
    }
  };

  const handleDeleteEvent = async (event: EventRow) => {
    const ok = window.confirm(`Delete event "${event.name || 'Unnamed Event'}"?`);
    if (!ok) return;

    try {
      await remove(ref(db, `meets/${activeMeetId}/events/${event.id}`));
      setMsg('Event deleted successfully');
    } catch (error: any) {
      setMsg(error.message || 'Failed to delete event');
    }
  };

  const activeMeetLabel = useMemo(() => {
    if (!activeMeet) return 'No active meet selected';
    return `${activeMeet.name || 'Unnamed Meet'} • ${
      activeMeet.venue || 'No venue'
    } • ${activeMeet.date || 'No date'} • ${activeMeet.laneCount || '—'} lanes`;
  }, [activeMeet]);

  return (
    <AppShell>
      <div style={{ display: 'grid', gap: 20 }}>
        <div
          style={{
            background: activeMeetId
              ? 'rgba(46,175,109,0.10)'
              : 'rgba(217,83,79,0.10)',
            border: activeMeetId
              ? '1px solid rgba(46,175,109,0.28)'
              : '1px solid rgba(217,83,79,0.28)',
            borderRadius: 18,
            padding: 18,
          }}
        >
          <h2 style={{ marginTop: 0, marginBottom: 8 }}>Active Meet</h2>
          <div style={{ color: activeMeetId ? '#d7ffe8' : '#ffd6d3' }}>
            {activeMeetLabel}
          </div>

          <div style={{ marginTop: 12 }}>
            <div style={{ color: '#9fb3c8', marginBottom: 8, fontSize: 13 }}>
              Categories for this meet
            </div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {meetCategories.length > 0 ? (
                meetCategories.map((cat) => (
                  <span key={cat} style={pillStyle}>
                    {cat}
                  </span>
                ))
              ) : (
                <span style={pillStyle}>No categories found</span>
              )}
            </div>
          </div>
        </div>

        <div style={panelStyle}>
          <h1 style={{ marginTop: 0 }}>Create Event</h1>
          <p style={{ color: '#9fb3c8', marginTop: 0 }}>
            Create swim events for the currently active meet.
          </p>

          <div style={gridStyle}>
            <div>
              <label style={labelStyle}>Event Number</label>
              <input
                value={eventNumber}
                onChange={(e) => setEventNumber(e.target.value)}
                placeholder="1"
                type="number"
                style={inputStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>Distance (m)</label>
              <input
                value={distance}
                onChange={(e) => setDistance(e.target.value)}
                placeholder="50"
                type="number"
                style={inputStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>Stroke</label>
              <select
                value={stroke}
                onChange={(e) => setStroke(e.target.value)}
                style={inputStyle}
              >
                {strokeOptions.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={labelStyle}>Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                style={inputStyle}
              >
                {genderOptions.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={labelStyle}>Category / Age Group</label>
              <select
                value={ageGroup}
                onChange={(e) => setAgeGroup(e.target.value)}
                style={inputStyle}
              >
                {meetCategories.length === 0 ? (
                  <option value="">No categories found</option>
                ) : (
                  meetCategories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))
                )}
              </select>
            </div>

            <div>
              <label style={labelStyle}>Event Type</label>
              <select
                value={eventType}
                onChange={(e) => setEventType(e.target.value)}
                style={inputStyle}
              >
                {eventTypeOptions.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={labelStyle}>Round</label>
              <select
                value={round}
                onChange={(e) => setRound(e.target.value as EventRound)}
                style={inputStyle}
              >
                {roundOptions.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>

            {round === 'Heats' ? (
              <>
                <div>
                  <label style={labelStyle}>Qualifies To Final Event</label>
                  <select
                    value={qualifiesToEventId}
                    onChange={(e) => setQualifiesToEventId(e.target.value)}
                    style={inputStyle}
                  >
                    <option value="">Select Final event</option>
                    {finalEventOptions.map((event) => (
                      <option key={event.id} value={event.id}>
                        {getEventDisplayLabel(event)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label style={labelStyle}>Qualify Count</label>
                  <input
                    value={qualifyCount}
                    onChange={(e) => setQualifyCount(e.target.value)}
                    type="number"
                    min={1}
                    style={inputStyle}
                  />
                  <div style={{ color: '#9fb3c8', fontSize: 12, marginTop: 6 }}>
                    Defaulted from meet lane count: {meetLaneCount || '—'}
                  </div>
                </div>
              </>
            ) : null}
          </div>

          <div
            style={{
              marginTop: 16,
              padding: 14,
              borderRadius: 14,
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.08)',
            }}
          >
            <div style={{ color: '#9fb3c8', fontSize: 13, marginBottom: 6 }}>
              Event Name Preview
            </div>
            <div style={{ fontWeight: 700, color: '#fff' }}>
              {distance && ageGroup
                ? buildEventName(distance, stroke, gender, ageGroup, eventType, round)
                : 'Complete the form to preview event name'}
            </div>
          </div>

          <div
            style={{
              display: 'flex',
              gap: 18,
              flexWrap: 'wrap',
              marginTop: 18,
            }}
          >
            <label style={checkRowStyle}>
              <input
                type="checkbox"
                checked={active}
                onChange={(e) => setActive(e.target.checked)}
              />
              <span>Event active</span>
            </label>
          </div>

          <div
            style={{
              display: 'flex',
              gap: 12,
              marginTop: 20,
              flexWrap: 'wrap',
            }}
          >
            <button
              onClick={handleSaveEvent}
              disabled={saving || meetCategories.length === 0}
              style={primaryBtnStyle}
            >
              {saving ? 'Saving...' : 'Save Event'}
            </button>

            <button onClick={resetForm} style={secondaryBtnStyle}>
              Reset
            </button>
          </div>

          <p style={{ marginTop: 16, color: '#f1d67a' }}>{msg}</p>
        </div>

        <div style={panelStyle}>
          <h2 style={{ marginTop: 0 }}>Saved Events</h2>

          {!activeMeetId ? (
            <p style={{ color: '#ffd6d3' }}>
              Please select an active meet first from the Meets page.
            </p>
          ) : sortedEvents.length === 0 ? (
            <p style={{ color: '#9fb3c8' }}>
              No events added for this meet yet.
            </p>
          ) : (
            <div style={{ display: 'grid', gap: 12 }}>
              {sortedEvents.map((event) => {
                const isEditing = editingEventId === event.id;
                const linkedFinal = event.qualifiesToEventId
                  ? events.find((e) => e.id === event.qualifiesToEventId)
                  : null;

                return (
                  <div
                    key={event.id}
                    style={{
                      border: '1px solid rgba(255,255,255,0.08)',
                      borderRadius: 16,
                      padding: 16,
                      background: 'rgba(255,255,255,0.04)',
                      opacity: event.active === false ? 0.65 : 1,
                    }}
                  >
                    {!isEditing ? (
                      <>
                        <div
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            gap: 12,
                            flexWrap: 'wrap',
                          }}
                        >
                          <div>
                            <div style={{ fontSize: 18, fontWeight: 700 }}>
                              Event {event.eventNumber || '—'} • {event.name || 'Unnamed Event'}
                            </div>
                            <div style={{ color: '#9fb3c8', marginTop: 4 }}>
                              {event.eventType || '—'} • {event.distance || '—'}m • {event.stroke || '—'}
                            </div>
                          </div>

                          <div
                            style={{
                              padding: '8px 12px',
                              borderRadius: 999,
                              background:
                                event.active === false
                                  ? 'rgba(217,83,79,0.16)'
                                  : 'rgba(46,175,109,0.16)',
                              border:
                                event.active === false
                                  ? '1px solid rgba(217,83,79,0.35)'
                                  : '1px solid rgba(46,175,109,0.35)',
                              color:
                                event.active === false ? '#ffd6d3' : '#d7ffe8',
                              fontSize: 13,
                              height: 'fit-content',
                            }}
                          >
                            {event.active === false ? 'Inactive' : 'Active'}
                          </div>
                        </div>

                        <div
                          style={{
                            display: 'flex',
                            gap: 10,
                            flexWrap: 'wrap',
                            marginTop: 14,
                          }}
                        >
                          <span style={pillStyle}>Gender: {event.gender || '—'}</span>
                          <span style={pillStyle}>Category: {event.ageGroup || '—'}</span>
                          <span style={pillStyle}>Type: {event.eventType || '—'}</span>
                          <span style={pillStyle}>Round: {event.round || '—'}</span>
                          {event.round === 'Heats' ? (
                            <span style={pillStyle}>
                              Qualify Count: {event.qualifyCount || meetLaneCount || '—'}
                            </span>
                          ) : null}
                        </div>

                        {event.round === 'Heats' ? (
                          <div
                            style={{
                              marginTop: 12,
                              color: '#9fb3c8',
                              fontSize: 13,
                            }}
                          >
                            Qualifies To:{' '}
                            <strong style={{ color: '#fff' }}>
                              {linkedFinal ? getEventDisplayLabel(linkedFinal) : 'Not linked'}
                            </strong>
                          </div>
                        ) : null}

                        <div
                          style={{
                            display: 'flex',
                            gap: 10,
                            flexWrap: 'wrap',
                            marginTop: 14,
                          }}
                        >
                          <button
                            onClick={() => handleStartEdit(event)}
                            style={secondaryBtnStyle}
                          >
                            Edit
                          </button>

                          <button
                            onClick={() => handleToggleEventActive(event)}
                            style={secondaryBtnStyle}
                          >
                            {event.active === false ? 'Activate' : 'Mark Inactive'}
                          </button>

                          <button
                            onClick={() => handleDeleteEvent(event)}
                            style={dangerBtnStyle}
                          >
                            Delete
                          </button>
                        </div>
                      </>
                    ) : (
                      <>
                        <h3 style={{ marginTop: 0 }}>Edit Event</h3>

                        <div style={gridStyle}>
                          <div>
                            <label style={labelStyle}>Event Number</label>
                            <input
                              value={editEventNumber}
                              onChange={(e) => setEditEventNumber(e.target.value)}
                              type="number"
                              style={inputStyle}
                            />
                          </div>

                          <div>
                            <label style={labelStyle}>Distance (m)</label>
                            <input
                              value={editDistance}
                              onChange={(e) => setEditDistance(e.target.value)}
                              type="number"
                              style={inputStyle}
                            />
                          </div>

                          <div>
                            <label style={labelStyle}>Stroke</label>
                            <select
                              value={editStroke}
                              onChange={(e) => setEditStroke(e.target.value)}
                              style={inputStyle}
                            >
                              {strokeOptions.map((item) => (
                                <option key={item} value={item}>
                                  {item}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label style={labelStyle}>Gender</label>
                            <select
                              value={editGender}
                              onChange={(e) => setEditGender(e.target.value)}
                              style={inputStyle}
                            >
                              {genderOptions.map((item) => (
                                <option key={item} value={item}>
                                  {item}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label style={labelStyle}>Category / Age Group</label>
                            <select
                              value={editAgeGroup}
                              onChange={(e) => setEditAgeGroup(e.target.value)}
                              style={inputStyle}
                            >
                              {meetCategories.map((cat) => (
                                <option key={cat} value={cat}>
                                  {cat}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label style={labelStyle}>Event Type</label>
                            <select
                              value={editEventType}
                              onChange={(e) => setEditEventType(e.target.value)}
                              style={inputStyle}
                            >
                              {eventTypeOptions.map((item) => (
                                <option key={item} value={item}>
                                  {item}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label style={labelStyle}>Round</label>
                            <select
                              value={editRound}
                              onChange={(e) => setEditRound(e.target.value as EventRound)}
                              style={inputStyle}
                            >
                              {roundOptions.map((item) => (
                                <option key={item} value={item}>
                                  {item}
                                </option>
                              ))}
                            </select>
                          </div>

                          {editRound === 'Heats' ? (
                            <>
                              <div>
                                <label style={labelStyle}>Qualifies To Final Event</label>
                                <select
                                  value={editQualifiesToEventId}
                                  onChange={(e) => setEditQualifiesToEventId(e.target.value)}
                                  style={inputStyle}
                                >
                                  <option value="">Select Final event</option>
                                  {finalEventOptions
                                    .filter((e) => e.id !== event.id)
                                    .map((eventRow) => (
                                      <option key={eventRow.id} value={eventRow.id}>
                                        {getEventDisplayLabel(eventRow)}
                                      </option>
                                    ))}
                                </select>
                              </div>

                              <div>
                                <label style={labelStyle}>Qualify Count</label>
                                <input
                                  value={editQualifyCount}
                                  onChange={(e) => setEditQualifyCount(e.target.value)}
                                  type="number"
                                  min={1}
                                  style={inputStyle}
                                />
                                <div style={{ color: '#9fb3c8', fontSize: 12, marginTop: 6 }}>
                                  Default from meet lane count: {meetLaneCount || '—'}
                                </div>
                              </div>
                            </>
                          ) : null}
                        </div>

                        <div
                          style={{
                            marginTop: 16,
                            padding: 14,
                            borderRadius: 14,
                            background: 'rgba(255,255,255,0.04)',
                            border: '1px solid rgba(255,255,255,0.08)',
                          }}
                        >
                          <div
                            style={{
                              color: '#9fb3c8',
                              fontSize: 13,
                              marginBottom: 6,
                            }}
                          >
                            Event Name Preview
                          </div>
                          <div style={{ fontWeight: 700, color: '#fff' }}>
                            {editDistance && editAgeGroup
                              ? buildEventName(
                                  editDistance,
                                  editStroke,
                                  editGender,
                                  editAgeGroup,
                                  editEventType,
                                  editRound
                                )
                              : 'Complete the form to preview event name'}
                          </div>
                        </div>

                        <div
                          style={{
                            display: 'flex',
                            gap: 18,
                            flexWrap: 'wrap',
                            marginTop: 18,
                          }}
                        >
                          <label style={checkRowStyle}>
                            <input
                              type="checkbox"
                              checked={editActive}
                              onChange={(e) => setEditActive(e.target.checked)}
                            />
                            <span>Event active</span>
                          </label>
                        </div>

                        <div
                          style={{
                            display: 'flex',
                            gap: 10,
                            flexWrap: 'wrap',
                            marginTop: 14,
                          }}
                        >
                          <button
                            onClick={() => handleUpdateEvent(event.id)}
                            disabled={updatingEventId === event.id}
                            style={primaryBtnStyle}
                          >
                            {updatingEventId === event.id ? 'Updating...' : 'Save Changes'}
                          </button>

                          <button
                            onClick={handleCancelEdit}
                            style={secondaryBtnStyle}
                          >
                            Cancel
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}

const panelStyle: React.CSSProperties = {
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 18,
  padding: 20,
};

const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
  gap: 14,
  marginTop: 18,
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  marginBottom: 8,
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '12px 14px',
  borderRadius: 12,
  border: '1px solid rgba(255,255,255,0.12)',
  background: 'rgba(255,255,255,0.06)',
  color: 'white',
  outline: 'none',
};

const checkRowStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 10,
  color: 'white',
};

const primaryBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: 'none',
  background: '#d4af37',
  color: '#071426',
  fontWeight: 700,
  cursor: 'pointer',
};

const secondaryBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: '1px solid rgba(255,255,255,0.12)',
  background: 'rgba(255,255,255,0.04)',
  color: 'white',
  fontWeight: 700,
  cursor: 'pointer',
};

const dangerBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: '1px solid rgba(217,83,79,0.35)',
  background: 'rgba(217,83,79,0.16)',
  color: '#ffd6d3',
  fontWeight: 700,
  cursor: 'pointer',
};

const pillStyle: React.CSSProperties = {
  padding: '8px 12px',
  borderRadius: 999,
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.08)',
  fontSize: 13,
};