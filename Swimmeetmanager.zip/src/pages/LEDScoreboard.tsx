import { useEffect, useMemo, useRef, useState } from 'react';
import { onValue, ref } from 'firebase/database';
import { db } from '../firebase/db.js';

type ScoreboardLane = {
  laneNumber?: number;
  swimmerName?: string;
  teamName?: string;
  time?: string;
  status?: string;
  place?: number | null;
};

type ScoreboardBoard = {
  eventNumber?: number;
  eventName?: string;
  heatNumber?: number;
  showTimes?: boolean;
  updatedAt?: number;
  rows?: Record<string, ScoreboardLane>;
};

type DisplayRow = {
  key: string;
  lane: number;
  name: string;
  team: string;
  time: string;
  status: string;
  place: number | null;
};

function compactEventTitle(
  eventNumber?: number,
  eventName?: string,
  heatNumber?: number
) {
  const raw = String(eventName || '').trim();
  if (!raw) {
    return `E${eventNumber || '—'} (${heatNumber ? `H${heatNumber}` : 'H—'})`;
  }

  let title = raw;

  title = title.replace(/\s*[—-]\s*Heats?$/i, '');
  title = title.replace(/\s*[—-]\s*Finals?$/i, '');
  title = title.replace(/\s*[—-]\s*Timed Finals?$/i, '');
  title = title.replace(/\s+/g, ' ').trim();

  const isFinal = /final/i.test(raw) && !/heat/i.test(raw);
  const suffix = isFinal ? `(F${heatNumber || 1})` : `(H${heatNumber || 1})`;

  return `E${eventNumber || '—'} - ${title} ${suffix}`;
}

export default function LEDScoreboard() {
  const [activeMeetId, setActiveMeetId] = useState('');
  const [board, setBoard] = useState<ScoreboardBoard | null>(null);
  const [meetName, setMeetName] = useState('');
  const [animateToken, setAnimateToken] = useState(0);
  const [resultsFlash, setResultsFlash] = useState(false);

  const prevUpdatedAtRef = useRef<number>(0);
  const prevShowTimesRef = useRef<boolean>(false);

  useEffect(() => {
    const unsub = onValue(ref(db, 'appState/activeMeetId'), (snap) => {
      setActiveMeetId(snap.val() || '');
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!activeMeetId) return;

    const meetRef = ref(db, `meets/${activeMeetId}`);
    const liveRef = ref(db, `meets/${activeMeetId}/liveDisplay`);

    const unsubMeet = onValue(meetRef, (snap) => {
      setMeetName(snap.val()?.name || '');
    });

    const unsubLive = onValue(liveRef, (snap) => {
      const nextBoard = snap.val()?.scoreboard || null;
      const nextUpdatedAt = Number(nextBoard?.updatedAt || 0);
      const nextShowTimes = !!nextBoard?.showTimes;

      const shouldAnimate =
        !!nextBoard &&
        (nextUpdatedAt !== prevUpdatedAtRef.current ||
          nextShowTimes !== prevShowTimesRef.current);

      setBoard(nextBoard);

      if (shouldAnimate) {
        setAnimateToken((v) => v + 1);

        if (nextShowTimes) {
          setResultsFlash(true);
          window.setTimeout(() => {
            setResultsFlash(false);
          }, 1400);
        }
      }

      prevUpdatedAtRef.current = nextUpdatedAt;
      prevShowTimesRef.current = nextShowTimes;
    });

    return () => {
      unsubMeet();
      unsubLive();
    };
  }, [activeMeetId]);

  const rows = useMemo(() => {
    return Object.entries(board?.rows || {}).map(([key, r]) => ({
      key,
      lane: Number(r.laneNumber || 0),
      name: r.swimmerName || '',
      team: r.teamName || '',
      time: r.time || '',
      status: String(r.status || 'OK'),
      place:
        typeof r.place === 'number' && !Number.isNaN(r.place) ? r.place : null,
    })) as DisplayRow[];
  }, [board]);

  const rowCount = rows.length || 8;

  const layoutVars = useMemo(() => {
    if (rowCount <= 4) {
      return {
        bodyPadding: '8px',
        headerFont: 'clamp(1.9rem, 4.4vw, 3.8rem)',
        meetFont: 'clamp(1.1rem, 2vw, 1.7rem)',
        statusFont: 'clamp(1rem, 1.9vw, 1.6rem)',
        thFont: 'clamp(1.15rem, 2vw, 1.8rem)',
        tdFont: 'clamp(2.4rem, 4.5vw, 4.2rem)',
        laneFont: 'clamp(2.4rem, 4.5vw, 4.2rem)',
        rowPad: '16px 12px',
      };
    }

    if (rowCount <= 6) {
      return {
        bodyPadding: '6px',
        headerFont: 'clamp(1.7rem, 3.8vw, 3.1rem)',
        meetFont: 'clamp(1rem, 1.8vw, 1.5rem)',
        statusFont: 'clamp(0.95rem, 1.8vw, 1.4rem)',
        thFont: 'clamp(1rem, 1.7vw, 1.5rem)',
        tdFont: 'clamp(2.4rem, 4.5vw, 4.2rem)',
        laneFont: 'clamp(2.4rem, 4.5vw, 4.2rem)',
        rowPad: '13px 10px',
      };
    }

    if (rowCount <= 8) {
      return {
        bodyPadding: '5px',
        headerFont: 'clamp(1.4rem, 3.1vw, 2.6rem)',
        meetFont: 'clamp(0.92rem, 1.5vw, 1.35rem)',
        statusFont: 'clamp(0.9rem, 1.5vw, 1.25rem)',
        thFont: 'clamp(0.95rem, 1.4vw, 1.3rem)',
        tdFont: 'clamp(1.45rem, 2.5vw, 2.3rem)',
        laneFont: 'clamp(1.55rem, 2.7vw, 2.5rem)',
        rowPad: '10px 9px',
      };
    }

    return {
      bodyPadding: '4px',
      headerFont: 'clamp(1.2rem, 2.5vw, 2.1rem)',
      meetFont: 'clamp(0.82rem, 1.25vw, 1.1rem)',
      statusFont: 'clamp(0.8rem, 1.2vw, 1rem)',
      thFont: 'clamp(0.82rem, 1.1vw, 1.05rem)',
      tdFont: 'clamp(1.15rem, 1.9vw, 1.75rem)',
      laneFont: 'clamp(1.2rem, 2vw, 1.9rem)',
      rowPad: '7px 8px',
    };
  }, [rowCount]);

  const displayTitle = compactEventTitle(
    board?.eventNumber,
    board?.eventName,
    board?.heatNumber
  );

  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800&display=swap"
        rel="stylesheet"
      />
      <link
        href="https://fonts.googleapis.com/css2?family=Doto:wght@600;700&display=swap"
        rel="stylesheet"
      />

      <style>{`
        :root {
          --pageHeaderH: 52px;
          --eventHeaderH: 62px;
          --bodyPad: ${layoutVars.bodyPadding};
          --meetFont: ${layoutVars.meetFont};
          --eventFont: ${layoutVars.headerFont};
          --statusFont: ${layoutVars.statusFont};
          --thFont: ${layoutVars.thFont};
          --tdFont: ${layoutVars.tdFont};
          --laneFont: ${layoutVars.laneFont};
          --rowPad: ${layoutVars.rowPad};
        }

        * {
          box-sizing: border-box;
        }

        html, body, #root {
          margin: 0;
          width: 100%;
          height: 100%;
          overflow: hidden;
          background: #000;
        }

        body {
          background-color: #000;
          color: #fff;
          font-family: 'Poppins', sans-serif;
        }

        .led-root {
          width: 100%;
          height: 100vh;
          display: grid;
          grid-template-rows: var(--pageHeaderH) var(--eventHeaderH) 1fr;
          overflow: hidden;
          background: #000;
        }

        .page-header {
          height: var(--pageHeaderH);
          min-height: var(--pageHeaderH);
          max-height: var(--pageHeaderH);
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          background: linear-gradient(90deg, #00264d 0%, #003366 50%, #00264d 100%);
          color: #fff;
          font-family: 'Poppins', sans-serif;
          font-size: var(--meetFont);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 1px;
          padding: 0 14px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .event-header {
          height: var(--eventHeaderH);
          min-height: var(--eventHeaderH);
          max-height: var(--eventHeaderH);
          display: grid;
          grid-template-columns: 1fr auto;
          align-items: center;
          gap: 14px;
          padding: 0 18px;
          background: #000;
          border-bottom: 2px solid rgba(255, 215, 0, 0.18);
        }

        .event-title {
          min-width: 0;
          color: #ffd700;
          font-family: 'Poppins', sans-serif;
          font-size: var(--eventFont);
          font-weight: 800;
          line-height: 1;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          text-shadow: 0 0 8px rgba(255, 215, 0, 0.45);
          text-align: center;
          justify-self: center;
          width: 100%;
        }

        .status-wrap {
          display: flex;
          align-items: center;
          gap: 10px;
          white-space: nowrap;
          font-size: var(--statusFont);
          font-weight: 800;
          text-transform: uppercase;
          font-family: 'Poppins', sans-serif;
          color: ${board?.showTimes ? '#00ff88' : '#ffd700'};
        }

        .ready-light {
          width: clamp(12px, 1.6vw, 18px);
          height: clamp(12px, 1.6vw, 18px);
          border-radius: 50%;
          background: #00ff88;
          box-shadow:
            0 0 6px #00ff88,
            0 0 12px #00ff88,
            0 0 20px rgba(0,255,136,0.65);
          animation: blinkReady 1s infinite ease-in-out;
          display: ${board?.showTimes ? 'none' : 'inline-block'};
        }

        @keyframes blinkReady {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.35;
            transform: scale(0.9);
          }
        }

        .table-wrap {
          width: 100%;
          height: 100%;
          padding: var(--bodyPad);
          overflow: hidden;
          display: flex;
          align-items: stretch;
        }

        table {
          width: 100%;
          height: 100%;
          border-collapse: collapse;
          table-layout: fixed;
        }

        thead th {
          background: #343434;
          color: #ffd700;
          font-family: 'Poppins', sans-serif;
          font-size: var(--thFont);
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.6px;
          padding: 8px 10px;
          line-height: 1.05;
          border-bottom: 2px solid #111;
        }

        tbody tr:nth-child(odd) {
          background: #ffdf00;
        }

        tbody tr:nth-child(even) {
          background: #c0c0c0;
        }

        td {
          color: #000;
          text-align: center;
          padding: var(--rowPad);
          font-size: var(--tdFont);
          font-weight: 700;
          text-transform: uppercase;
          line-height: 1;
          border-bottom: 2px solid rgba(0,0,0,0.18);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .lane-cell {
          font-family: 'Poppins', sans-serif;
          font-size: var(--laneFont);
          font-weight: 900;
          letter-spacing: 0.5px;
          width: 10%;
        }

        .name-cell {
          width: 36%;
          font-family: 'Doto', monospace;
          font-weight: 700;
        }

        .team-cell {
          width: 32%;
          font-family: 'Doto', monospace;
          font-weight: 700;
        }

        .time-cell {
          width: 22%;
          font-family: 'Doto', monospace;
          font-weight: 800;
          letter-spacing: 1px;
          position: relative;
        }

        .time-cell.flash {
          animation: timeFlash 1.2s ease;
        }

        @keyframes timeFlash {
          0% {
            background: rgba(0, 255, 136, 0.55);
            box-shadow: inset 0 0 0 9999px rgba(0,255,136,0.18);
          }
          100% {
            background: transparent;
            box-shadow: inset 0 0 0 9999px rgba(0,255,136,0);
          }
        }

        .empty-cell {
          font-family: 'Poppins', sans-serif;
          font-size: clamp(1rem, 2vw, 2rem);
          font-weight: 700;
        }

        .anim-row {
          opacity: 0;
          transform: translateY(18px) scale(0.985);
          animation: rowIn 520ms cubic-bezier(.2,.8,.2,1) forwards;
          will-change: transform, opacity;
        }

        @keyframes rowIn {
          from {
            opacity: 0;
            transform: translateY(18px) scale(0.985);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
      `}</style>

      <div className="led-root">
        <div className="page-header">{meetName || 'Panthers Swim Meet'}</div>

        <div className="event-header">
          <div className="event-title">{displayTitle}</div>

          <div className="status-wrap">
            {!board?.showTimes ? <span className="ready-light" /> : null}
            <span>{board?.showTimes ? 'Results' : 'Ready'}</span>
          </div>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th style={{ width: '10%' }}>Lane</th>
                <th style={{ width: '36%' }}>Name</th>
                <th style={{ width: '32%' }}>Team</th>
                <th style={{ width: '22%' }}>Time</th>
              </tr>
            </thead>

            <tbody key={animateToken}>
              {rows.length === 0 ? (
                <tr>
                  <td className="empty-cell" colSpan={4}>
                    Waiting...
                  </td>
                </tr>
              ) : (
                rows.map((r, index) => (
                  <tr
                    key={`${animateToken}-${r.key}-${r.lane}-${r.name}`}
                    className="anim-row"
                    style={{
                      animationDelay: `${index * 70}ms`,
                    }}
                  >
                    <td className="lane-cell">{r.lane}</td>
                    <td className="name-cell">{r.name || '—'}</td>
                    <td className="team-cell">{r.team || '—'}</td>
                    <td
                      className={`time-cell ${
                        resultsFlash && board?.showTimes ? 'flash' : ''
                      }`}
                    >
                      {board?.showTimes ? r.time || '—' : ''}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
