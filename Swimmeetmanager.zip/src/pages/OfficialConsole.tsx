import { useEffect, useMemo, useState } from 'react';
import { onValue, push, ref, remove, set, update } from 'firebase/database';
import AppShell from '../components/AppShell';
import { auth } from '../firebase/auth.js';
import { db } from '../firebase/db.js';

type MeetRow = {
  id: string;
  name?: string;
  venue?: string;
  date?: string;
  laneCount?: number;
};

type EventRound = 'Heats' | 'Final' | 'Timed Final';

type EventRow = {
  id: string;
  eventNumber?: number;
  distance?: string;
  stroke?: string;
  gender?: string;
  ageGroup?: string;
  eventType?: string;
  round?: EventRound;
  qualifiesToEventId?: string;
  qualifyCount?: number;
  relay?: boolean;
  name?: string;
  active?: boolean;
};

type EntryRow = {
  id: string;
  swimmerId?: string;
  swimmerName?: string;
  gender?: string;
  ageGroup?: string;
  teamId?: string;
  teamName?: string;
  eventId?: string;
  eventNumber?: number;
  eventName?: string;
  laneSeedTime?: string;
  status?: string;
  active?: boolean;
  createdAt?: number;
  createdBy?: string;
};

type ResultRow = {
  entryId?: string;
  swimmerId?: string;
  swimmerName?: string;
  teamId?: string;
  teamName?: string;
  eventId?: string;
  eventNumber?: number;
  eventName?: string;
  heatNumber?: number;
  laneNumber?: number;
  seedTime?: string;
  heatFinalTime?: string;
  status?: string;
  place?: number | null;
  active?: boolean;
  updatedAt?: number;
  updatedBy?: string;
};

type RankedQualifierRow = {
  resultId: string;
  entryId: string;
  swimmerId: string;
  swimmerName: string;
  teamId: string;
  teamName: string;
  heatNumber: number;
  laneNumber: number;
  time: string;
  hundredths: number;
  status: string;
  rank: number | null;
  qualified: boolean;
  alreadyInFinal: boolean;
};

type FinalEntryView = {
  entryId: string;
  swimmerId: string;
  swimmerName: string;
  teamId: string;
  teamName: string;
  seedTime: string;
  status: string;
};

function normalizeStatus(value?: string) {
  const s = String(value || 'OK')
    .trim()
    .toUpperCase();
  if (['OK', 'DQ', 'NS', 'SCR'].includes(s)) return s;
  return 'OK';
}

function parseSwimTimeToHundredths(value?: string) {
  const text = String(value || '').trim();
  if (!text) return null;

  const match = text.match(/^(\d{2}):(\d{2})\.(\d{2})$/);
  if (!match) return null;

  const mm = Number(match[1]);
  const ss = Number(match[2]);
  const hh = Number(match[3]);

  if (Number.isNaN(mm) || Number.isNaN(ss) || Number.isNaN(hh)) return null;

  return mm * 6000 + ss * 100 + hh;
}

function getLaneOrder(laneCount: number) {
  if (laneCount === 6) return [3, 4, 2, 5, 1, 6];
  if (laneCount === 8) return [4, 5, 3, 6, 2, 7, 1, 8];
  if (laneCount === 10) return [5, 6, 4, 7, 3, 8, 2, 9, 1, 10];
  return Array.from({ length: laneCount || 8 }, (_, i) => i + 1);
}

function isEntryCompleted(
  entryId: string,
  resultsById: Record<string, ResultRow>
) {
  const result = resultsById[entryId];
  if (!result) return false;

  const status = normalizeStatus(result.status);
  const time = String(result.heatFinalTime || '').trim();

  return (
    status === 'DQ' ||
    status === 'NS' ||
    status === 'SCR' ||
    (status === 'OK' && !!time)
  );
}

export default function OfficialConsole() {
  const [activeMeetId, setActiveMeetId] = useState('');
  const [activeMeet, setActiveMeet] = useState<MeetRow | null>(null);

  const [events, setEvents] = useState<EventRow[]>([]);
  const [entries, setEntries] = useState<EntryRow[]>([]);
  const [resultsById, setResultsById] = useState<Record<string, ResultRow>>({});

  const [selectedHeatsEventId, setSelectedHeatsEventId] = useState('');
  const [msg, setMsg] = useState('');
  const [working, setWorking] = useState(false);

  const activeMeetLabel = useMemo(() => {
    if (!activeMeet) return 'No active meet selected';
    return `${activeMeet.name || 'Unnamed Meet'} • ${
      activeMeet.venue || 'No venue'
    } • ${activeMeet.date || 'No date'} • ${activeMeet.laneCount || '—'} lanes`;
  }, [activeMeet]);

  const heatsEventOptions = useMemo(() => {
    return [...events]
      .filter(
        (event) =>
          event.active !== false &&
          event.round === 'Heats' &&
          !!String(event.qualifiesToEventId || '').trim()
      )
      .sort((a, b) => Number(a.eventNumber || 0) - Number(b.eventNumber || 0));
  }, [events]);

  const selectedHeatsEvent = useMemo(() => {
    return (
      heatsEventOptions.find((event) => event.id === selectedHeatsEventId) ||
      null
    );
  }, [heatsEventOptions, selectedHeatsEventId]);

  const linkedFinalEvent = useMemo(() => {
    if (!selectedHeatsEvent?.qualifiesToEventId) return null;
    return (
      events.find((e) => e.id === selectedHeatsEvent.qualifiesToEventId) || null
    );
  }, [events, selectedHeatsEvent]);

  const heatsEventEntries = useMemo(() => {
    if (!selectedHeatsEventId) return [] as EntryRow[];
    return entries
      .filter(
        (entry) =>
          entry.eventId === selectedHeatsEventId &&
          entry.active !== false &&
          String(entry.status || '').toLowerCase() !== 'scratch'
      )
      .sort((a, b) => {
        const nameA = String(a.swimmerName || '').toLowerCase();
        const nameB = String(b.swimmerName || '').toLowerCase();
        return nameA.localeCompare(nameB);
      });
  }, [entries, selectedHeatsEventId]);

  const finalEventEntries = useMemo(() => {
    if (!linkedFinalEvent?.id) return [] as FinalEntryView[];

    return entries
      .filter(
        (entry) =>
          entry.eventId === linkedFinalEvent.id && entry.active !== false
      )
      .map((entry) => ({
        entryId: entry.id,
        swimmerId: String(entry.swimmerId || ''),
        swimmerName: String(entry.swimmerName || ''),
        teamId: String(entry.teamId || ''),
        teamName: String(entry.teamName || ''),
        seedTime: String(entry.laneSeedTime || ''),
        status: String(entry.status || 'Entered'),
      }))
      .sort((a, b) => a.swimmerName.localeCompare(b.swimmerName));
  }, [entries, linkedFinalEvent]);

  const finalEventEntrySwimmerIds = useMemo(() => {
    return new Set(
      finalEventEntries.map((row) => row.swimmerId).filter(Boolean)
    );
  }, [finalEventEntries]);

  const completionSummary = useMemo(() => {
    const total = heatsEventEntries.length;
    const completed = heatsEventEntries.filter((entry) =>
      isEntryCompleted(entry.id, resultsById)
    ).length;

    return {
      total,
      completed,
      isComplete: total > 0 && completed === total,
    };
  }, [heatsEventEntries, resultsById]);

  const qualifyCount = useMemo(() => {
    if (!selectedHeatsEvent) return 0;
    const explicit = Number(selectedHeatsEvent.qualifyCount || 0);
    if (explicit > 0) return explicit;
    return Number(activeMeet?.laneCount || 0);
  }, [selectedHeatsEvent, activeMeet]);

  const rankedQualifiers = useMemo(() => {
    if (!selectedHeatsEventId) return [] as RankedQualifierRow[];

    const rows = heatsEventEntries
      .map((entry) => {
        const resultPair = Object.entries(resultsById).find(
          ([, result]) => String(result.entryId || '') === entry.id
        );
        const resultId = resultPair?.[0] || '';
        const result = resultPair?.[1];

        const status = normalizeStatus(result?.status || 'OK');
        const time = String(result?.heatFinalTime || '').trim();
        const hundredths =
          status === 'OK' && time ? parseSwimTimeToHundredths(time) : null;

        return {
          resultId,
          entryId: entry.id,
          swimmerId: String(entry.swimmerId || ''),
          swimmerName: String(entry.swimmerName || ''),
          teamId: String(entry.teamId || ''),
          teamName: String(entry.teamName || ''),
          heatNumber: Number(result?.heatNumber || 0),
          laneNumber: Number(result?.laneNumber || 0),
          time,
          hundredths: hundredths ?? Number.MAX_SAFE_INTEGER,
          status,
          rank: null,
          qualified: false,
          alreadyInFinal: finalEventEntrySwimmerIds.has(
            String(entry.swimmerId || '')
          ),
        };
      })
      .filter((row) => !!row.swimmerId);

    const sorted = [...rows].sort((a, b) => {
      const aValid =
        a.status === 'OK' && a.time && a.hundredths !== Number.MAX_SAFE_INTEGER;
      const bValid =
        b.status === 'OK' && b.time && b.hundredths !== Number.MAX_SAFE_INTEGER;

      if (aValid && bValid) {
        if (a.hundredths !== b.hundredths) return a.hundredths - b.hundredths;
      } else if (aValid && !bValid) {
        return -1;
      } else if (!aValid && bValid) {
        return 1;
      }

      const statusOrder = (status: string) => {
        if (status === 'OK') return 0;
        if (status === 'NS') return 1;
        if (status === 'DQ') return 2;
        if (status === 'SCR') return 3;
        return 9;
      };

      const diff = statusOrder(a.status) - statusOrder(b.status);
      if (diff !== 0) return diff;

      if (a.heatNumber !== b.heatNumber) return a.heatNumber - b.heatNumber;
      if (a.laneNumber !== b.laneNumber) return a.laneNumber - b.laneNumber;

      return a.swimmerName.localeCompare(b.swimmerName);
    });

    let currentRank = 1;
    const validRows = sorted.filter(
      (row) =>
        row.status === 'OK' &&
        row.time &&
        row.hundredths !== Number.MAX_SAFE_INTEGER
    );

    const qualifiedSwimmerIds = new Set(
      validRows.slice(0, qualifyCount).map((row) => row.swimmerId)
    );

    return sorted.map((row) => {
      const isRanked =
        row.status === 'OK' &&
        row.time &&
        row.hundredths !== Number.MAX_SAFE_INTEGER;
      const output: RankedQualifierRow = {
        ...row,
        rank: isRanked ? currentRank++ : null,
        qualified: qualifiedSwimmerIds.has(row.swimmerId),
      };
      return output;
    });
  }, [
    selectedHeatsEventId,
    heatsEventEntries,
    resultsById,
    qualifyCount,
    finalEventEntrySwimmerIds,
  ]);

  const qualifiedRows = useMemo(() => {
    return rankedQualifiers.filter((row) => row.qualified);
  }, [rankedQualifiers]);

  const canPromote = useMemo(() => {
    return (
      !!selectedHeatsEvent && !!linkedFinalEvent && qualifiedRows.length > 0
    );
  }, [selectedHeatsEvent, linkedFinalEvent, qualifiedRows]);

  useEffect(() => {
    const activeRef = ref(db, 'appState/activeMeetId');
    const unsub = onValue(activeRef, (snap) => {
      setActiveMeetId(snap.val() || '');
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!activeMeetId) {
      setActiveMeet(null);
      return;
    }

    const meetRef = ref(db, `meets/${activeMeetId}`);
    const unsub = onValue(meetRef, (snap) => {
      if (!snap.exists()) {
        setActiveMeet(null);
        return;
      }

      setActiveMeet({
        id: activeMeetId,
        ...snap.val(),
      });
    });

    return () => unsub();
  }, [activeMeetId]);

  useEffect(() => {
    if (!activeMeetId) {
      setEvents([]);
      setEntries([]);
      setResultsById({});
      setSelectedHeatsEventId('');
      return;
    }

    const eventsRef = ref(db, `meets/${activeMeetId}/events`);
    const entriesRef = ref(db, `meets/${activeMeetId}/entries`);
    const resultsRef = ref(db, `meets/${activeMeetId}/results`);

    const unsubEvents = onValue(eventsRef, (snap) => {
      const val = snap.val();
      if (!val) {
        setEvents([]);
        return;
      }

      const rows: EventRow[] = Object.entries(val).map(([id, item]: any) => ({
        id,
        ...item,
      }));
      setEvents(rows);
    });

    const unsubEntries = onValue(entriesRef, (snap) => {
      const val = snap.val();
      if (!val) {
        setEntries([]);
        return;
      }

      const rows: EntryRow[] = Object.entries(val).map(([id, item]: any) => ({
        id,
        ...item,
      }));
      setEntries(rows);
    });

    const unsubResults = onValue(resultsRef, (snap) => {
      setResultsById((snap.val() as Record<string, ResultRow>) || {});
    });

    return () => {
      unsubEvents();
      unsubEntries();
      unsubResults();
    };
  }, [activeMeetId]);

  useEffect(() => {
    if (!heatsEventOptions.length) {
      setSelectedHeatsEventId('');
      return;
    }

    setSelectedHeatsEventId((prev) => {
      if (prev && heatsEventOptions.some((event) => event.id === prev))
        return prev;
      return heatsEventOptions[0].id;
    });
  }, [heatsEventOptions]);

  const handlePromoteFinalists = async (alsoSeed: boolean) => {
    if (!activeMeetId || !selectedHeatsEvent || !linkedFinalEvent) {
      setMsg('Please select a valid heats event');
      return;
    }

    if (!qualifiedRows.length) {
      setMsg('No qualified swimmers found');
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      setMsg('You are not logged in');
      return;
    }

    const ok = window.confirm(
      alsoSeed
        ? `Promote qualified swimmers to ${
            linkedFinalEvent.name || 'Final'
          } and reseed final lanes?`
        : `Promote qualified swimmers to ${linkedFinalEvent.name || 'Final'}?`
    );
    if (!ok) return;

    setWorking(true);
    setMsg(
      alsoSeed ? 'Promoting and seeding finalists...' : 'Promoting finalists...'
    );

    try {
      const existingFinalEntries = entries.filter(
        (entry) =>
          entry.eventId === linkedFinalEvent.id && entry.active !== false
      );

      const existingBySwimmerId = new Map<string, EntryRow>();
      existingFinalEntries.forEach((entry) => {
        if (entry.swimmerId)
          existingBySwimmerId.set(String(entry.swimmerId), entry);
      });

      for (const row of qualifiedRows) {
        const existing = existingBySwimmerId.get(row.swimmerId);

        if (existing) {
          await update(
            ref(db, `meets/${activeMeetId}/entries/${existing.id}`),
            {
              swimmerId: row.swimmerId,
              swimmerName: row.swimmerName,
              gender:
                linkedFinalEvent.gender || selectedHeatsEvent.gender || '',
              ageGroup:
                linkedFinalEvent.ageGroup || selectedHeatsEvent.ageGroup || '',
              teamId: row.teamId,
              teamName: row.teamName,
              eventId: linkedFinalEvent.id,
              eventNumber: linkedFinalEvent.eventNumber || 0,
              eventName: linkedFinalEvent.name || '',
              laneSeedTime: row.time || '',
              status: 'Qualified',
              active: true,
            }
          );
        } else {
          const newEntryRef = push(ref(db, `meets/${activeMeetId}/entries`));
          await set(newEntryRef, {
            swimmerId: row.swimmerId,
            swimmerName: row.swimmerName,
            gender: linkedFinalEvent.gender || selectedHeatsEvent.gender || '',
            ageGroup:
              linkedFinalEvent.ageGroup || selectedHeatsEvent.ageGroup || '',
            teamId: row.teamId,
            teamName: row.teamName,
            eventId: linkedFinalEvent.id,
            eventNumber: linkedFinalEvent.eventNumber || 0,
            eventName: linkedFinalEvent.name || '',
            laneSeedTime: row.time || '',
            status: 'Qualified',
            active: true,
            createdAt: Date.now(),
            createdBy: user.uid,
          });
        }
      }

      if (alsoSeed) {
        const qualifiers = [...qualifiedRows].sort(
          (a, b) => a.hundredths - b.hundredths
        );
        const laneCount = Number(
          activeMeet?.laneCount || qualifyCount || qualifiers.length || 6
        );
        const laneOrder = getLaneOrder(laneCount);

        const refreshedFinalEntries = entries.filter(
          (entry) =>
            entry.eventId === linkedFinalEvent.id &&
            entry.active !== false &&
            qualifiers.some(
              (q) => q.swimmerId === String(entry.swimmerId || '')
            )
        );

        const finalEntriesBySwimmerId = new Map<string, EntryRow>();
        refreshedFinalEntries.forEach((entry) => {
          if (entry.swimmerId)
            finalEntriesBySwimmerId.set(String(entry.swimmerId), entry);
        });

        const lanePayload: Record<
          string,
          {
            laneNumber: number;
            entryId: string;
            swimmerId: string;
            swimmerName: string;
            teamId: string;
            teamName: string;
            seedTime: string;
            heatNumber: number;
          }
        > = {};

        qualifiers.slice(0, laneOrder.length).forEach((qualifier, index) => {
          const laneNumber = laneOrder[index];
          const finalEntry = finalEntriesBySwimmerId.get(qualifier.swimmerId);

          if (!finalEntry) return;

          lanePayload[`lane${laneNumber}`] = {
            laneNumber,
            entryId: finalEntry.id,
            swimmerId: qualifier.swimmerId,
            swimmerName: qualifier.swimmerName,
            teamId: qualifier.teamId,
            teamName: qualifier.teamName,
            seedTime: qualifier.time || '',
            heatNumber: 1,
          };
        });

        await set(
          ref(db, `meets/${activeMeetId}/seeding/${linkedFinalEvent.id}`),
          {
            generatedAt: Date.now(),
            generatedBy: user.uid,
            laneCount,
            eventId: linkedFinalEvent.id,
            eventNumber: linkedFinalEvent.eventNumber || 0,
            eventName: linkedFinalEvent.name || '',
            heats: {
              heat1: {
                heatNumber: 1,
                lanes: lanePayload,
              },
            },
            meta: {
              seededCount: Object.keys(lanePayload).length,
              unseededCount: 0,
            },
          }
        );
      }

      setMsg(
        alsoSeed
          ? `Qualified swimmers promoted and final seeded for ${
              linkedFinalEvent.name || 'Final'
            }`
          : `Qualified swimmers promoted to ${linkedFinalEvent.name || 'Final'}`
      );
    } catch (error: any) {
      setMsg(error.message || 'Failed to build finalists');
    } finally {
      setWorking(false);
    }
  };

  const handleClearFinalEntries = async () => {
    if (!activeMeetId || !linkedFinalEvent) {
      setMsg('No linked final event selected');
      return;
    }

    const ok = window.confirm(
      `Clear all current finalists and seeding for ${
        linkedFinalEvent.name || 'Final'
      }?`
    );
    if (!ok) return;

    setWorking(true);
    setMsg('Clearing final event entries and seeding...');

    try {
      const finalEntries = entries.filter(
        (entry) =>
          entry.eventId === linkedFinalEvent.id && entry.active !== false
      );

      for (const entry of finalEntries) {
        await remove(ref(db, `meets/${activeMeetId}/entries/${entry.id}`));
      }

      await remove(
        ref(db, `meets/${activeMeetId}/seeding/${linkedFinalEvent.id}`)
      );

      setMsg(
        `Cleared finalists and seeding for ${linkedFinalEvent.name || 'Final'}`
      );
    } catch (error: any) {
      setMsg(error.message || 'Failed to clear final event');
    } finally {
      setWorking(false);
    }
  };

  return (
    <AppShell>
      <div style={{ display: 'grid', gap: 20 }}>
        <div
          style={{
            background: activeMeetId
              ? 'rgba(46,175,109,0.10)'
              : 'rgba(217,83,79,0.10)',
            border: activeMeetId
              ? '1px solid rgba(46,175,109,0.28)'
              : '1px solid rgba(217,83,79,0.28)',
            borderRadius: 18,
            padding: 18,
          }}
        >
          <h2 style={{ marginTop: 0, marginBottom: 8 }}>Active Meet</h2>
          <div style={{ color: activeMeetId ? '#d7ffe8' : '#ffd6d3' }}>
            {activeMeetLabel}
          </div>
        </div>

        <div style={panelStyle}>
          <h1 style={{ marginTop: 0 }}>Official Console</h1>
          <p style={{ color: '#9fb3c8', marginTop: 0 }}>
            Build finalists from completed heats and reseed the final event.
          </p>

          <div style={gridStyle}>
            <div>
              <label style={labelStyle}>Heats Event</label>
              <select
                value={selectedHeatsEventId}
                onChange={(e) => setSelectedHeatsEventId(e.target.value)}
                style={inputStyle}
              >
                <option value="">Select Heats event</option>
                {heatsEventOptions.map((event) => (
                  <option key={event.id} value={event.id}>
                    Event {event.eventNumber || '—'} •{' '}
                    {event.name || 'Unnamed Event'}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={labelStyle}>Linked Final Event</label>
              <div style={readOnlyBoxStyle}>
                {linkedFinalEvent
                  ? `Event ${linkedFinalEvent.eventNumber || '—'} • ${
                      linkedFinalEvent.name || 'Unnamed Final'
                    }`
                  : 'No linked final event'}
              </div>
            </div>

            <div>
              <label style={labelStyle}>Qualify Count</label>
              <div style={readOnlyBoxStyle}>{qualifyCount || '—'}</div>
            </div>
          </div>

          <div
            style={{
              display: 'flex',
              gap: 10,
              flexWrap: 'wrap',
              marginTop: 16,
            }}
          >
            <span style={pillStyle}>
              Heats Entries: {completionSummary.total}
            </span>
            <span style={pillStyle}>
              Completed: {completionSummary.completed}/{completionSummary.total}
            </span>
            <span
              style={{
                ...pillStyle,
                background: completionSummary.isComplete
                  ? 'rgba(46,175,109,0.16)'
                  : 'rgba(212,175,55,0.18)',
                border: completionSummary.isComplete
                  ? '1px solid rgba(46,175,109,0.35)'
                  : '1px solid rgba(212,175,55,0.35)',
                color: completionSummary.isComplete ? '#d7ffe8' : '#fff0b5',
              }}
            >
              {completionSummary.isComplete
                ? 'Heats Complete'
                : 'Heats In Progress'}
            </span>
            <span style={pillStyle}>
              Finalists Found: {qualifiedRows.length}
            </span>
            <span style={pillStyle}>
              Already in Final: {finalEventEntries.length}
            </span>
          </div>

          <div
            style={{
              display: 'flex',
              gap: 12,
              flexWrap: 'wrap',
              marginTop: 18,
            }}
          >
            <button
              onClick={() => handlePromoteFinalists(false)}
              disabled={!canPromote || working}
              style={
                !canPromote || working ? disabledBtnStyle : primaryBtnStyle
              }
            >
              {working ? 'Working...' : 'Promote Finalists'}
            </button>

            <button
              onClick={() => handlePromoteFinalists(true)}
              disabled={!canPromote || working}
              style={
                !canPromote || working ? disabledBtnStyle : secondaryBtnStyle
              }
            >
              {working ? 'Working...' : 'Promote + Reseed Final'}
            </button>

            <button
              onClick={handleClearFinalEntries}
              disabled={!linkedFinalEvent || working}
              style={
                !linkedFinalEvent || working ? disabledBtnStyle : dangerBtnStyle
              }
            >
              Clear Final Entries + Seeding
            </button>
          </div>

          <p style={{ marginTop: 16, color: '#f1d67a' }}>{msg}</p>
        </div>

        <div style={panelStyle}>
          <h2 style={{ marginTop: 0 }}>Qualified Swimmers</h2>

          {!selectedHeatsEvent ? (
            <p style={{ color: '#9fb3c8' }}>
              Select a heats event to see qualifiers.
            </p>
          ) : rankedQualifiers.length === 0 ? (
            <p style={{ color: '#9fb3c8' }}>
              No swimmers/results found for this heats event.
            </p>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table
                style={{
                  width: '100%',
                  borderCollapse: 'collapse',
                  minWidth: 980,
                }}
              >
                <thead>
                  <tr>
                    {[
                      'Rank',
                      'Qualified',
                      'Already in Final',
                      'Swimmer',
                      'Team',
                      'Heat',
                      'Lane',
                      'Time',
                      'Status',
                    ].map((h) => (
                      <th
                        key={h}
                        style={{
                          textAlign: 'left',
                          padding: '10px 12px',
                          borderBottom: '1px solid rgba(255,255,255,0.12)',
                          color: '#cfe0f1',
                          background: 'rgba(255,255,255,0.04)',
                        }}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rankedQualifiers.map((row) => (
                    <tr key={`${row.resultId}-${row.entryId}`}>
                      <td style={tdStyle}>{row.rank ?? '—'}</td>
                      <td style={tdStyle}>
                        <span
                          style={{
                            ...pillStyle,
                            background: row.qualified
                              ? 'rgba(46,175,109,0.16)'
                              : 'rgba(255,255,255,0.06)',
                            border: row.qualified
                              ? '1px solid rgba(46,175,109,0.35)'
                              : '1px solid rgba(255,255,255,0.08)',
                            color: row.qualified ? '#d7ffe8' : '#fff',
                          }}
                        >
                          {row.qualified ? 'Yes' : 'No'}
                        </span>
                      </td>
                      <td style={tdStyle}>
                        <span
                          style={{
                            ...pillStyle,
                            background: row.alreadyInFinal
                              ? 'rgba(212,175,55,0.18)'
                              : 'rgba(255,255,255,0.06)',
                            border: row.alreadyInFinal
                              ? '1px solid rgba(212,175,55,0.35)'
                              : '1px solid rgba(255,255,255,0.08)',
                            color: row.alreadyInFinal ? '#fff0b5' : '#fff',
                          }}
                        >
                          {row.alreadyInFinal ? 'Yes' : 'No'}
                        </span>
                      </td>
                      <td style={tdStyle}>
                        <div style={{ fontWeight: 700 }}>
                          {row.swimmerName || '—'}
                        </div>
                      </td>
                      <td style={tdStyle}>{row.teamName || '—'}</td>
                      <td style={tdStyle}>{row.heatNumber || '—'}</td>
                      <td style={tdStyle}>{row.laneNumber || '—'}</td>
                      <td style={tdStyle}>{row.time || '—'}</td>
                      <td style={tdStyle}>{row.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div style={panelStyle}>
          <h2 style={{ marginTop: 0 }}>Current Final Event Entries</h2>

          {!linkedFinalEvent ? (
            <p style={{ color: '#9fb3c8' }}>No linked final event selected.</p>
          ) : finalEventEntries.length === 0 ? (
            <p style={{ color: '#9fb3c8' }}>
              No swimmers currently entered in this final.
            </p>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table
                style={{
                  width: '100%',
                  borderCollapse: 'collapse',
                  minWidth: 760,
                }}
              >
                <thead>
                  <tr>
                    {['Swimmer', 'Team', 'Seed Time', 'Status'].map((h) => (
                      <th
                        key={h}
                        style={{
                          textAlign: 'left',
                          padding: '10px 12px',
                          borderBottom: '1px solid rgba(255,255,255,0.12)',
                          color: '#cfe0f1',
                          background: 'rgba(255,255,255,0.04)',
                        }}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {finalEventEntries.map((row) => (
                    <tr key={row.entryId}>
                      <td style={tdStyle}>{row.swimmerName || '—'}</td>
                      <td style={tdStyle}>{row.teamName || '—'}</td>
                      <td style={tdStyle}>{row.seedTime || '—'}</td>
                      <td style={tdStyle}>{row.status || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}

const panelStyle: React.CSSProperties = {
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 18,
  padding: 20,
};

const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
  gap: 14,
  marginTop: 18,
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  marginBottom: 8,
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '12px 14px',
  borderRadius: 12,
  border: '1px solid rgba(255,255,255,0.12)',
  background: 'rgba(255,255,255,0.06)',
  color: 'white',
  outline: 'none',
};

const readOnlyBoxStyle: React.CSSProperties = {
  width: '100%',
  minHeight: 46,
  padding: '12px 14px',
  borderRadius: 12,
  border: '1px solid rgba(255,255,255,0.12)',
  background: 'rgba(255,255,255,0.04)',
  color: 'white',
  display: 'flex',
  alignItems: 'center',
};

const tdStyle: React.CSSProperties = {
  padding: '10px 12px',
  borderBottom: '1px solid rgba(255,255,255,0.08)',
  verticalAlign: 'top',
};

const primaryBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: 'none',
  background: '#d4af37',
  color: '#071426',
  fontWeight: 700,
  cursor: 'pointer',
};

const secondaryBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: '1px solid rgba(255,255,255,0.12)',
  background: 'rgba(255,255,255,0.04)',
  color: 'white',
  fontWeight: 700,
  cursor: 'pointer',
};

const dangerBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: '1px solid rgba(217,83,79,0.35)',
  background: 'rgba(217,83,79,0.16)',
  color: '#ffd6d3',
  fontWeight: 700,
  cursor: 'pointer',
};

const disabledBtnStyle: React.CSSProperties = {
  padding: '12px 18px',
  borderRadius: 12,
  border: 'none',
  background: 'rgba(255,255,255,0.10)',
  color: 'rgba(255,255,255,0.55)',
  fontWeight: 700,
  cursor: 'not-allowed',
};

const pillStyle: React.CSSProperties = {
  padding: '8px 12px',
  borderRadius: 999,
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.08)',
  fontSize: 13,
};
