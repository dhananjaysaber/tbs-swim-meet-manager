import { useEffect, useState } from 'react';
import { signInWithEmailAndPassword, onAuthStateChanged } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase/auth';

export default function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (user) {
        navigate('/dashboard', { replace: true });
      }
    });

    return () => unsub();
  }, [navigate]);

  const handleLogin = async () => {
    if (!email || !password) {
      setMsg('Please enter email and password');
      return;
    }

    setLoading(true);
    setMsg('Signing in...');

    try {
      await signInWithEmailAndPassword(auth, email, password);
      setMsg('Login successful');
      navigate('/dashboard', { replace: true });
    } catch (error: any) {
      setMsg(error.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'grid',
        placeItems: 'center',
        padding: '24px',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: '420px',
          background: 'rgba(255,255,255,0.06)',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: '18px',
          padding: '24px',
          boxShadow: '0 20px 50px rgba(0,0,0,0.28)',
        }}
      >
        <h1 style={{ marginTop: 0, marginBottom: 8 }}>
          Panthers Swim Meet Manager
        </h1>
        <p style={{ marginTop: 0, color: '#9fb3c8' }}>Sign in to continue</p>

        <div style={{ display: 'grid', gap: '12px', marginTop: '20px' }}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{
              padding: '14px',
              borderRadius: '12px',
              border: '1px solid rgba(255,255,255,0.12)',
              background: 'rgba(255,255,255,0.06)',
              color: 'white',
              outline: 'none',
            }}
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              padding: '14px',
              borderRadius: '12px',
              border: '1px solid rgba(255,255,255,0.12)',
              background: 'rgba(255,255,255,0.06)',
              color: 'white',
              outline: 'none',
            }}
          />

          <button
            onClick={handleLogin}
            disabled={loading}
            style={{
              padding: '14px',
              borderRadius: '12px',
              border: 'none',
              background: '#d4af37',
              color: '#071426',
              fontWeight: 700,
              cursor: 'pointer',
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? 'Signing In...' : 'Sign In'}
          </button>
        </div>

        <p style={{ marginTop: '16px', color: '#f1d67a' }}>{msg}</p>
      </div>
    </div>
  );
}
